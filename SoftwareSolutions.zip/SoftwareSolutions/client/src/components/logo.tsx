import React from "react";
import logoPath from "@assets/IMG_2097.png";

interface LogoProps {
  size?: "sm" | "md" | "lg" | "xl";
  className?: string;
  showText?: boolean;
  textClassName?: string;
}

const Logo: React.FC<LogoProps> = ({ 
  size = "md", 
  className = "", 
  showText = true,
  textClassName = "" 
}) => {
  const sizeClasses = {
    sm: "w-8 h-8",
    md: "w-10 h-10",
    lg: "w-12 h-12",
    xl: "w-16 h-16",
  };

  return (
    <div className="flex items-center space-x-2">
      <img 
        src={logoPath} 
        alt="GrantedByFluffy Logo" 
        className={`${sizeClasses[size]} ${className}`} 
      />
      {showText && (
        <span className={`font-bold font-inter tracking-tight ${textClassName || "text-xl text-primary"}`}>
          GrantedByFluffy
        </span>
      )}
    </div>
  );
};

export default Logo;
