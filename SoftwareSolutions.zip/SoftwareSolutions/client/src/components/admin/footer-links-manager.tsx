import { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Trash2, Plus, Edit, Save, X } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';

interface LinkItem {
  id: string;
  label: string;
  href: string;
}

interface FooterLinksManagerProps {
  links: LinkItem[];
  onChange: (links: LinkItem[]) => void;
  title?: string;
  description?: string;
}

export function FooterLinksManager({ 
  links, 
  onChange, 
  title = "Footer Links", 
  description = "Manage links displayed in the footer" 
}: FooterLinksManagerProps) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [newLink, setNewLink] = useState<Partial<LinkItem>>({ label: '', href: '' });
  const [editedLink, setEditedLink] = useState<LinkItem | null>(null);
  const [isAdding, setIsAdding] = useState(false);

  const handleAddLink = useCallback(() => {
    if (newLink.label && newLink.href) {
      const link: LinkItem = {
        id: uuidv4(),
        label: newLink.label,
        href: newLink.href
      };
      onChange([...links, link]);
      setNewLink({ label: '', href: '' });
      setIsAdding(false);
    }
  }, [newLink, links, onChange]);

  const handleUpdateLink = useCallback(() => {
    if (editedLink && editingId) {
      onChange(links.map(link => link.id === editingId ? editedLink : link));
      setEditingId(null);
      setEditedLink(null);
    }
  }, [editedLink, editingId, links, onChange]);

  const handleRemoveLink = useCallback((id: string) => {
    onChange(links.filter(link => link.id !== id));
  }, [links, onChange]);

  const handleStartEdit = useCallback((link: LinkItem) => {
    setEditingId(link.id);
    setEditedLink(link);
  }, []);

  const handleCancelEdit = useCallback(() => {
    setEditingId(null);
    setEditedLink(null);
  }, []);

  const handleCancelAdd = useCallback(() => {
    setIsAdding(false);
    setNewLink({ label: '', href: '' });
  }, []);

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold">{title}</h3>
          <p className="text-sm text-muted-foreground">{description}</p>
        </div>
        {!isAdding && (
          <Button 
            size="sm" 
            variant="outline" 
            onClick={() => setIsAdding(true)}
            className="flex items-center gap-1"
          >
            <Plus className="h-4 w-4" />
            Add Link
          </Button>
        )}
      </div>

      {isAdding && (
        <Card>
          <CardContent className="pt-6">
            <div className="grid gap-4">
              <div>
                <Label htmlFor="new-label">Link Text</Label>
                <Input
                  id="new-label"
                  value={newLink.label}
                  onChange={(e) => setNewLink({...newLink, label: e.target.value})}
                  placeholder="e.g., Donate Now"
                />
              </div>
              <div>
                <Label htmlFor="new-href">URL</Label>
                <Input
                  id="new-href"
                  value={newLink.href}
                  onChange={(e) => setNewLink({...newLink, href: e.target.value})}
                  placeholder="e.g., /donate"
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" size="sm" onClick={handleCancelAdd}>
                  <X className="h-4 w-4 mr-1" />
                  Cancel
                </Button>
                <Button size="sm" onClick={handleAddLink}>
                  <Plus className="h-4 w-4 mr-1" />
                  Add
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {links.length > 0 ? (
        <div className="space-y-2">
          {links.map((link) => (
            <div 
              key={link.id} 
              className="group flex items-center justify-between p-3 border rounded-md bg-card hover:bg-accent/5"
            >
              {editingId === link.id ? (
                <div className="flex-1 grid grid-cols-3 gap-2">
                  <Input
                    value={editedLink?.label || ''}
                    onChange={(e) => setEditedLink({...editedLink!, label: e.target.value})}
                    placeholder="Link text"
                    className="col-span-1"
                  />
                  <Input
                    value={editedLink?.href || ''}
                    onChange={(e) => setEditedLink({...editedLink!, href: e.target.value})}
                    placeholder="URL"
                    className="col-span-1"
                  />
                  <div className="flex justify-end gap-2">
                    <Button size="icon" variant="ghost" onClick={handleCancelEdit} className="h-8 w-8">
                      <X className="h-4 w-4" />
                    </Button>
                    <Button size="icon" variant="ghost" onClick={handleUpdateLink} className="h-8 w-8">
                      <Save className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ) : (
                <>
                  <div className="flex-1">
                    <div className="font-medium">{link.label}</div>
                    <div className="text-sm text-muted-foreground">{link.href}</div>
                  </div>
                  <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button size="icon" variant="ghost" onClick={() => handleStartEdit(link)} className="h-8 w-8">
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button size="icon" variant="ghost" onClick={() => handleRemoveLink(link.id)} className="h-8 w-8 text-destructive">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </>
              )}
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center p-6 bg-muted/20 rounded-md">
          <p className="text-muted-foreground">No links added yet.</p>
        </div>
      )}
    </div>
  );
}