import React, { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Plus, Trash, MoveUp, MoveDown } from 'lucide-react';

interface Project {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  technologies: string[];
  highlights: string[];
}

interface DynamicProjectsManagerProps {
  projects: Project[];
  onChange: (projects: Project[]) => void;
}

export function DynamicProjectsManager({ projects = [], onChange }: DynamicProjectsManagerProps) {
  const [items, setItems] = useState<Project[]>(projects);

  // Update local state when props change
  useEffect(() => {
    setItems(projects);
  }, [projects]);
  
  // Function to update parent when we make changes
  const updateParent = useCallback((newItems: Project[]) => {
    setItems(newItems);
    onChange(newItems);
  }, [onChange]);

  // Add a new project item
  const addItem = () => {
    const newItem: Project = {
      id: `project-${Date.now()}`,
      title: '',
      description: '',
      imageUrl: '',
      technologies: ['React', 'TypeScript'],
      highlights: ['Feature 1', 'Feature 2']
    };
    updateParent([...items, newItem]);
  };

  // Remove a project item
  const removeItem = (index: number) => {
    const newItems = [...items];
    newItems.splice(index, 1);
    updateParent(newItems);
  };

  // Handle changes to project properties
  const handleChange = (index: number, field: keyof Project, value: any) => {
    const newItems = [...items];
    newItems[index] = {
      ...newItems[index],
      [field]: value,
    };
    updateParent(newItems);
  };

  // Handle array field changes (technologies & highlights)
  const handleArrayChange = (index: number, field: 'technologies' | 'highlights', value: string) => {
    const array = value.split(',').map(item => item.trim()).filter(Boolean);
    handleChange(index, field, array);
  };

  // Move an item up in the list
  const moveUp = (index: number) => {
    if (index === 0) return;
    const newItems = [...items];
    const temp = newItems[index];
    newItems[index] = newItems[index - 1];
    newItems[index - 1] = temp;
    updateParent(newItems);
  };

  // Move an item down in the list
  const moveDown = (index: number) => {
    if (index === items.length - 1) return;
    const newItems = [...items];
    const temp = newItems[index];
    newItems[index] = newItems[index + 1];
    newItems[index + 1] = temp;
    updateParent(newItems);
  };

  return (
    <div className="space-y-4">
      {items.map((item, index) => (
        <Card key={item.id} className="relative">
          <CardContent className="pt-4">
            <div className="grid gap-4">
              <div className="grid gap-2">
                <Label htmlFor={`project-title-${index}`}>Project Title</Label>
                <Input
                  id={`project-title-${index}`}
                  value={item.title}
                  onChange={(e) => handleChange(index, 'title', e.target.value)}
                  placeholder="E.g., E-Commerce Platform"
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor={`project-description-${index}`}>Description</Label>
                <Textarea
                  id={`project-description-${index}`}
                  value={item.description}
                  onChange={(e) => handleChange(index, 'description', e.target.value)}
                  placeholder="Describe this project..."
                  rows={3}
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor={`project-image-${index}`}>Image URL</Label>
                <Input
                  id={`project-image-${index}`}
                  value={item.imageUrl || ''}
                  onChange={(e) => handleChange(index, 'imageUrl', e.target.value)}
                  placeholder="https://example.com/image.jpg"
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor={`project-technologies-${index}`}>Technologies (comma-separated)</Label>
                <Input
                  id={`project-technologies-${index}`}
                  value={item.technologies.join(', ')}
                  onChange={(e) => handleArrayChange(index, 'technologies', e.target.value)}
                  placeholder="E.g., React, Node.js, Express"
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor={`project-highlights-${index}`}>Highlights (comma-separated)</Label>
                <Textarea
                  id={`project-highlights-${index}`}
                  value={item.highlights.join(', ')}
                  onChange={(e) => handleArrayChange(index, 'highlights', e.target.value)}
                  placeholder="E.g., Feature 1, Feature 2, Feature 3"
                  rows={3}
                />
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between border-t pt-4">
            <div className="flex space-x-2">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => moveUp(index)}
                disabled={index === 0}
              >
                <MoveUp className="h-4 w-4 mr-1" />
                Move Up
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => moveDown(index)}
                disabled={index === items.length - 1}
              >
                <MoveDown className="h-4 w-4 mr-1" />
                Move Down
              </Button>
            </div>
            <Button
              variant="destructive"
              size="sm"
              onClick={() => removeItem(index)}
            >
              <Trash className="h-4 w-4 mr-1" />
              Remove
            </Button>
          </CardFooter>
        </Card>
      ))}

      <Button 
        className="w-full" 
        variant="outline" 
        onClick={addItem}
      >
        <Plus className="h-4 w-4 mr-1" />
        Add Project
      </Button>
    </div>
  );
}