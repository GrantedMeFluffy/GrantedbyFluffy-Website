import React, { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Plus, Trash, MoveUp, MoveDown } from 'lucide-react';
import { Switch } from '@/components/ui/switch';

interface FeaturedProduct {
  id: string;
  name: string;
  description: string;
  imageUrl: string;
  price: number;
  discountPrice?: number;
  featured?: boolean;
  stripePriceId?: string;
}

interface DynamicProductsManagerProps {
  products: FeaturedProduct[];
  onChange: (products: FeaturedProduct[]) => void;
}

export function DynamicProductsManager({ products = [], onChange }: DynamicProductsManagerProps) {
  const [items, setItems] = useState<FeaturedProduct[]>(products);

  // Update local state when props change
  useEffect(() => {
    setItems(products);
  }, [products]);
  
  // Function to update parent when we make changes
  const updateParent = useCallback((newItems: FeaturedProduct[]) => {
    setItems(newItems);
    onChange(newItems);
  }, [onChange]);

  // Add a new product item
  const addItem = () => {
    const newItem: FeaturedProduct = {
      id: `product-${Date.now()}`,
      name: '',
      description: '',
      imageUrl: '',
      price: 0,
      discountPrice: 0,
      stripePriceId: '',
      featured: true
    };
    updateParent([...items, newItem]);
  };

  // Remove a product item
  const removeItem = (index: number) => {
    const newItems = [...items];
    newItems.splice(index, 1);
    updateParent(newItems);
  };

  // Handle changes to product properties
  const handleChange = (index: number, field: keyof FeaturedProduct, value: any) => {
    const newItems = [...items];
    newItems[index] = {
      ...newItems[index],
      [field]: value,
    };
    updateParent(newItems);
  };

  // Move an item up in the list
  const moveUp = (index: number) => {
    if (index === 0) return;
    const newItems = [...items];
    const temp = newItems[index];
    newItems[index] = newItems[index - 1];
    newItems[index - 1] = temp;
    updateParent(newItems);
  };

  // Move an item down in the list
  const moveDown = (index: number) => {
    if (index === items.length - 1) return;
    const newItems = [...items];
    const temp = newItems[index];
    newItems[index] = newItems[index + 1];
    newItems[index + 1] = temp;
    updateParent(newItems);
  };

  return (
    <div className="space-y-4">
      {items.map((item, index) => (
        <Card key={item.id} className="relative">
          <CardContent className="pt-4">
            <div className="grid gap-4">
              <div className="grid gap-2">
                <Label htmlFor={`product-name-${index}`}>Product Name</Label>
                <Input
                  id={`product-name-${index}`}
                  value={item.name}
                  onChange={(e) => handleChange(index, 'name', e.target.value)}
                  placeholder="E.g., Professional Website Template"
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor={`product-description-${index}`}>Description</Label>
                <Textarea
                  id={`product-description-${index}`}
                  value={item.description}
                  onChange={(e) => handleChange(index, 'description', e.target.value)}
                  placeholder="Describe this product..."
                  rows={3}
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor={`product-image-${index}`}>Image URL</Label>
                <Input
                  id={`product-image-${index}`}
                  value={item.imageUrl || ''}
                  onChange={(e) => handleChange(index, 'imageUrl', e.target.value)}
                  placeholder="https://example.com/image.jpg"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor={`product-price-${index}`}>Price ($)</Label>
                  <Input
                    id={`product-price-${index}`}
                    type="number"
                    value={item.price || 0}
                    onChange={(e) => handleChange(index, 'price', parseFloat(e.target.value) || 0)}
                    placeholder="29.99"
                  />
                </div>

                <div className="grid gap-2">
                  <Label htmlFor={`product-discount-${index}`}>Discount Price ($)</Label>
                  <Input
                    id={`product-discount-${index}`}
                    type="number"
                    value={item.discountPrice || 0}
                    onChange={(e) => handleChange(index, 'discountPrice', parseFloat(e.target.value) || 0)}
                    placeholder="19.99"
                  />
                </div>
              </div>

              <div className="grid gap-2 mt-2">
                <Label htmlFor={`product-stripe-id-${index}`}>Stripe Price ID</Label>
                <Input
                  id={`product-stripe-id-${index}`}
                  value={item.stripePriceId || ''}
                  onChange={(e) => handleChange(index, 'stripePriceId', e.target.value)}
                  placeholder="price_XXXXXXXXXXXXXXXX"
                />
                <p className="text-xs text-muted-foreground">
                  Enter your Stripe price ID for checkout processing
                </p>
              </div>

              <div className="flex items-center space-x-2 mt-2">
                <Switch
                  id={`product-featured-${index}`}
                  checked={item.featured}
                  onCheckedChange={(checked) => handleChange(index, 'featured', checked)}
                />
                <Label htmlFor={`product-featured-${index}`}>Featured on homepage</Label>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between border-t pt-4">
            <div className="flex space-x-2">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => moveUp(index)}
                disabled={index === 0}
              >
                <MoveUp className="h-4 w-4 mr-1" />
                Move Up
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => moveDown(index)}
                disabled={index === items.length - 1}
              >
                <MoveDown className="h-4 w-4 mr-1" />
                Move Down
              </Button>
            </div>
            <Button
              variant="destructive"
              size="sm"
              onClick={() => removeItem(index)}
            >
              <Trash className="h-4 w-4 mr-1" />
              Remove
            </Button>
          </CardFooter>
        </Card>
      ))}

      <Button 
        className="w-full" 
        variant="outline" 
        onClick={addItem}
      >
        <Plus className="h-4 w-4 mr-1" />
        Add Featured Product
      </Button>
    </div>
  );
}