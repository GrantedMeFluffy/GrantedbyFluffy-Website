import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Trash, Plus } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';

interface FooterLink {
  id: string;
  label: string;
  href: string;
}

interface FooterQuickLinksManagerProps {
  links: FooterLink[];
  onChange: (links: FooterLink[]) => void;
}

export function FooterQuickLinksManager({ links = [], onChange }: FooterQuickLinksManagerProps) {
  const [quickLinks, setQuickLinks] = useState<FooterLink[]>(links);

  // Handle adding a new link
  const handleAddLink = () => {
    const newLink = {
      id: uuidv4(),
      label: 'New Link',
      href: '#'
    };
    
    const updatedLinks = [...quickLinks, newLink];
    setQuickLinks(updatedLinks);
    onChange(updatedLinks);
  };

  // Handle removing a link
  const handleRemoveLink = (id: string) => {
    const updatedLinks = quickLinks.filter(link => link.id !== id);
    setQuickLinks(updatedLinks);
    onChange(updatedLinks);
  };

  // Handle updating a link
  const handleUpdateLink = (id: string, field: 'label' | 'href', value: string) => {
    const updatedLinks = quickLinks.map(link => {
      if (link.id === id) {
        return { ...link, [field]: value };
      }
      return link;
    });
    setQuickLinks(updatedLinks);
    onChange(updatedLinks);
  };

  return (
    <div className="space-y-4">
      {quickLinks.map(link => (
        <Card key={link.id} className="relative">
          <CardContent className="pt-6 grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor={`link-label-${link.id}`}>Link Label</Label>
              <Input
                id={`link-label-${link.id}`}
                value={link.label}
                onChange={e => handleUpdateLink(link.id, 'label', e.target.value)}
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor={`link-href-${link.id}`}>Link URL</Label>
              <Input
                id={`link-href-${link.id}`}
                value={link.href}
                onChange={e => handleUpdateLink(link.id, 'href', e.target.value)}
                className="mt-1"
              />
            </div>
            <Button
              variant="destructive"
              size="icon"
              onClick={() => handleRemoveLink(link.id)}
              className="absolute top-2 right-2"
            >
              <Trash className="w-4 h-4" />
            </Button>
          </CardContent>
        </Card>
      ))}
      <Button onClick={handleAddLink} className="w-full mt-4" variant="outline">
        <Plus className="w-4 h-4 mr-2" /> Add Link
      </Button>
    </div>
  );
}