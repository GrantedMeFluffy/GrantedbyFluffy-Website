import React, { useState, useEffect } from "react";

const ProgressBar: React.FC = () => {
  const [width, setWidth] = useState(0);
  
  useEffect(() => {
    const updateProgressBar = () => {
      const scrollTop = window.scrollY;
      const scrollHeight = document.documentElement.scrollHeight - window.innerHeight;
      const scrollPercentage = (scrollTop / scrollHeight) * 100;
      
      setWidth(scrollPercentage);
    };
    
    window.addEventListener("scroll", updateProgressBar);
    
    return () => window.removeEventListener("scroll", updateProgressBar);
  }, []);
  
  return (
    <div 
      className="fixed top-0 left-0 h-1 bg-gradient-to-r from-accent-red via-accent-teal to-accent-yellow z-[9999] transition-all duration-200"
      style={{ width: `${width}%` }}
    ></div>
  );
};

export default ProgressBar;
