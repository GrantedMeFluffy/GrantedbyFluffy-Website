import React, { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import Logo from "./logo";
import { cn } from "@/lib/utils";
import ThemeToggle from "./theme-toggle";
import { useSettings } from "@/hooks/use-settings";

interface NavLink {
  href: string;
  label: string;
}

// Base nav links
const baseNavLinks: NavLink[] = [
  { href: "#about", label: "About" },
  { href: "#services", label: "Services" },
  { href: "#shop", label: "Shop" },
  { href: "#contact", label: "Contact" }
];

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [location] = useLocation();
  const { settings } = useSettings();
  
  // Construct nav links based on settings
  const navLinks = [...baseNavLinks];
  
  // Always add donate link during transition
  navLinks.push({
    href: "/donate",
    label: settings.donateNavLinkText || "Donate"
  });

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <header className={cn(
      "fixed w-full top-0 z-40 transition-all duration-300 bg-background/80 backdrop-blur-md",
      isScrolled ? "py-2 shadow-md" : "py-4"
    )}>
      <nav className="container mx-auto px-6">
        <div className="flex justify-between items-center">
          <Link href="/" className="flex items-center space-x-2">
            <Logo />
          </Link>
          
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              link.href.startsWith('#') && location === '/' ? (
                <a 
                  key={link.label}
                  href={link.href} 
                  className="font-medium text-foreground hover:text-primary transition-colors"
                >
                  {link.label}
                </a>
              ) : (
                <Link 
                  key={link.label}
                  href={link.href.startsWith('#') ? `/${link.href}` : link.href} 
                  className="font-medium text-foreground hover:text-primary transition-colors"
                >
                  {link.label}
                </Link>
              )
            ))}
          </div>
          
          <div className="flex items-center space-x-4">
            <ThemeToggle />
            <button 
              className="md:hidden focus:outline-none text-foreground" 
              onClick={toggleMobileMenu}
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={`${isMobileMenuOpen ? 'hidden' : 'block'}`}>
                <line x1="4" x2="20" y1="12" y2="12" />
                <line x1="4" x2="20" y1="6" y2="6" />
                <line x1="4" x2="20" y1="18" y2="18" />
              </svg>
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={`${isMobileMenuOpen ? 'block' : 'hidden'}`}>
                <path d="M18 6 6 18" />
                <path d="m6 6 12 12" />
              </svg>
            </button>
          </div>
        </div>
        
        {/* Mobile menu */}
        <div className={cn(
          "md:hidden pt-4 pb-2 animate-fadeIn",
          isMobileMenuOpen ? "block" : "hidden"
        )}>
          <div className="flex flex-col space-y-4">
            {navLinks.map((link) => (
              link.href.startsWith('#') && location === '/' ? (
                <a 
                  key={link.label}
                  href={link.href} 
                  className="font-medium text-foreground hover:text-primary transition-colors py-2"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {link.label}
                </a>
              ) : (
                <Link 
                  key={link.label}
                  href={link.href.startsWith('#') ? `/${link.href}` : link.href}
                  className="font-medium text-foreground hover:text-primary transition-colors py-2"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {link.label}
                </Link>
              )
            ))}
          </div>
        </div>
      </nav>
    </header>
  );
};

export default Navbar;
