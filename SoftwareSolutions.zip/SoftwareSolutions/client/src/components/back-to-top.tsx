import React, { useState, useEffect } from "react";
import { cn } from "@/lib/utils";

interface BackToTopProps {
  className?: string;
}

const BackToTop: React.FC<BackToTopProps> = ({ className }) => {
  const [isVisible, setIsVisible] = useState(false);
  
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth"
    });
  };
  
  useEffect(() => {
    const toggleVisibility = () => {
      if (window.scrollY > 300) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };
    
    window.addEventListener("scroll", toggleVisibility);
    
    return () => window.removeEventListener("scroll", toggleVisibility);
  }, []);
  
  return (
    <button
      onClick={scrollToTop}
      className={cn(
        "fixed bottom-6 right-6 z-50 p-3 rounded-full",
        "bg-background/80 backdrop-blur-md border border-border",
        "hover:bg-muted transition-all duration-300",
        isVisible ? "opacity-100 visible" : "opacity-0 invisible",
        className
      )}
      aria-label="Back to top"
    >
      <i className="fas fa-arrow-up text-accent-red"></i>
    </button>
  );
};

export default BackToTop;
