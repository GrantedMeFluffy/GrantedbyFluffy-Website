import React from "react";
import Logo from "./logo";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { Form, FormControl, FormField, FormItem } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useSettings } from "@/hooks/use-settings";

const newsletterSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
});

type NewsletterFormValues = z.infer<typeof newsletterSchema>;

const Footer: React.FC = () => {
  const { toast } = useToast();
  const { settings } = useSettings();
  const form = useForm<NewsletterFormValues>({
    resolver: zodResolver(newsletterSchema),
    defaultValues: {
      email: "",
    },
  });

  const onSubmit = async (data: NewsletterFormValues) => {
    try {
      await apiRequest("POST", "/api/newsletter", data);
      toast({
        title: "Success!",
        description: "You have been subscribed to our newsletter.",
      });
      form.reset();
    } catch (error) {
      toast({
        title: "Error!",
        description: error instanceof Error ? error.message : "Failed to subscribe. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <footer className="bg-neutral-900 text-white py-16 relative overflow-hidden">
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Company Info Column - Always shown */}
          <div>
            <Link href="/" className="flex items-center space-x-2 mb-6">
              <Logo textClassName="text-white" />
            </Link>
            <p className="text-neutral-400 mb-6 text-sm">
              {settings.footerText || "Premium software solutions crafted with precision and care by an independent developer passionate about creating exceptional user experiences."}
            </p>
            <div className="flex space-x-4">
              {settings.twitterUrl && (
                <a href={settings.twitterUrl} target="_blank" rel="noopener noreferrer" className="text-neutral-400 hover:text-accent-red transition-colors">
                  <i className="fab fa-twitter"></i>
                </a>
              )}
              {settings.linkedinUrl && (
                <a href={settings.linkedinUrl} target="_blank" rel="noopener noreferrer" className="text-neutral-400 hover:text-accent-teal transition-colors">
                  <i className="fab fa-linkedin-in"></i>
                </a>
              )}
              {settings.githubUrl && (
                <a href={settings.githubUrl} target="_blank" rel="noopener noreferrer" className="text-neutral-400 hover:text-accent-yellow transition-colors">
                  <i className="fab fa-github"></i>
                </a>
              )}
              {(!settings.twitterUrl && !settings.linkedinUrl && !settings.githubUrl) && (
                <>
                  <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="text-neutral-400 hover:text-accent-red transition-colors">
                    <i className="fab fa-twitter"></i>
                  </a>
                  <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="text-neutral-400 hover:text-accent-teal transition-colors">
                    <i className="fab fa-linkedin-in"></i>
                  </a>
                  <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="text-neutral-400 hover:text-accent-yellow transition-colors">
                    <i className="fab fa-github"></i>
                  </a>
                </>
              )}
            </div>
          </div>
          
          {/* Quick Links Column - Can be hidden via settings */}
          {(settings.showQuickLinks === undefined || settings.showQuickLinks) && (
            <div>
              <h3 className="text-lg font-bold mb-6 font-inter">{settings.quickLinksTitle || "Quick Links"}</h3>
              <ul className="space-y-3">
                {settings.footerQuickLinks && Array.isArray(settings.footerQuickLinks) ? (
                  settings.footerQuickLinks.map((link: {id: string, label: string, href: string}) => (
                    <li key={link.id}>
                      <a href={link.href} className="text-neutral-400 hover:text-accent-red transition-colors flex items-center">
                        <i className="fas fa-chevron-right text-xs mr-2"></i>
                        <span>{link.label}</span>
                      </a>
                    </li>
                  ))
                ) : (
                  // Fallback for legacy format
                  <>
                    {settings.quickLinksAbout && (
                      <li>
                        <a href="#about" className="text-neutral-400 hover:text-accent-red transition-colors flex items-center">
                          <i className="fas fa-chevron-right text-xs mr-2"></i>
                          <span>{settings.quickLinksAbout || "About"}</span>
                        </a>
                      </li>
                    )}
                    {settings.quickLinksServices && (
                      <li>
                        <a href="#services" className="text-neutral-400 hover:text-accent-red transition-colors flex items-center">
                          <i className="fas fa-chevron-right text-xs mr-2"></i>
                          <span>{settings.quickLinksServices || "Services"}</span>
                        </a>
                      </li>
                    )}
                    {settings.quickLinksPortfolio && (
                      <li>
                        <a href="#portfolio" className="text-neutral-400 hover:text-accent-red transition-colors flex items-center">
                          <i className="fas fa-chevron-right text-xs mr-2"></i>
                          <span>{settings.quickLinksPortfolio || "Portfolio"}</span>
                        </a>
                      </li>
                    )}
                    {settings.quickLinksShop && (
                      <li>
                        <a href="#shop" className="text-neutral-400 hover:text-accent-red transition-colors flex items-center">
                          <i className="fas fa-chevron-right text-xs mr-2"></i>
                          <span>{settings.quickLinksShop || "Shop"}</span>
                        </a>
                      </li>
                    )}
                    {/* Donation link in Quick Links - Static during transition */}
                    <li>
                      <Link href="/donate" className="text-neutral-400 hover:text-accent-red transition-colors flex items-center">
                        <i className="fas fa-chevron-right text-xs mr-2"></i>
                        <span>Donate</span>
                      </Link>
                    </li>
                    
                    {/* Dynamic donation links from settings */}
                    {settings.quickLinksDonateLinks && Array.isArray(settings.quickLinksDonateLinks) && 
                      settings.quickLinksDonateLinks.map((link: {id: string, label: string, href: string}) => (
                        <li key={link.id}>
                          <Link href={link.href} className="text-neutral-400 hover:text-accent-red transition-colors flex items-center">
                            <i className="fas fa-chevron-right text-xs mr-2"></i>
                            <span>{link.label}</span>
                          </Link>
                        </li>
                      ))
                    }
                    {settings.quickLinksContact && (
                      <li>
                        <a href="#contact" className="text-neutral-400 hover:text-accent-red transition-colors flex items-center">
                          <i className="fas fa-chevron-right text-xs mr-2"></i>
                          <span>{settings.quickLinksContact || "Contact"}</span>
                        </a>
                      </li>
                    )}
                  </>
                )}
              </ul>
            </div>
          )}
          
          {/* Services Column - Can be hidden via settings */}
          {(settings.showServicesLinks === undefined || settings.showServicesLinks) && (
            <div>
              <h3 className="text-lg font-bold mb-6 font-inter">{settings.servicesLinksTitle || "Services"}</h3>
              <ul className="space-y-3">
                {settings.footerServiceLinks && Array.isArray(settings.footerServiceLinks) ? (
                  settings.footerServiceLinks.map((link: {id: string, label: string, href: string}) => (
                    <li key={link.id}>
                      <a href={link.href} className="text-neutral-400 hover:text-accent-teal transition-colors flex items-center">
                        <i className="fas fa-check text-xs mr-2"></i>
                        <span>{link.label}</span>
                      </a>
                    </li>
                  ))
                ) : (
                  // Fallback for legacy format
                  <>
                    {settings.servicesLink1 && (
                      <li>
                        <a href="#services" className="text-neutral-400 hover:text-accent-teal transition-colors flex items-center">
                          <i className="fas fa-check text-xs mr-2"></i>
                          <span>{settings.servicesLink1 || "Custom Software Development"}</span>
                        </a>
                      </li>
                    )}
                    {settings.servicesLink2 && (
                      <li>
                        <a href="#services" className="text-neutral-400 hover:text-accent-teal transition-colors flex items-center">
                          <i className="fas fa-check text-xs mr-2"></i>
                          <span>{settings.servicesLink2 || "API Development & Integration"}</span>
                        </a>
                      </li>
                    )}
                    {settings.servicesLink3 && (
                      <li>
                        <a href="#services" className="text-neutral-400 hover:text-accent-teal transition-colors flex items-center">
                          <i className="fas fa-check text-xs mr-2"></i>
                          <span>{settings.servicesLink3 || "UI/UX Design"}</span>
                        </a>
                      </li>
                    )}
                    {settings.servicesLink4 && (
                      <li>
                        <a href="#services" className="text-neutral-400 hover:text-accent-teal transition-colors flex items-center">
                          <i className="fas fa-check text-xs mr-2"></i>
                          <span>{settings.servicesLink4 || "Software Consulting"}</span>
                        </a>
                      </li>
                    )}
                    {settings.servicesLink5 && (
                      <li>
                        <a href="#services" className="text-neutral-400 hover:text-accent-teal transition-colors flex items-center">
                          <i className="fas fa-check text-xs mr-2"></i>
                          <span>{settings.servicesLink5 || "Maintenance & Support"}</span>
                        </a>
                      </li>
                    )}
                  </>
                )}
              </ul>
            </div>
          )}
          
          {/* Newsletter Column - Can be hidden via settings */}
          {(settings.showNewsletter === undefined || settings.showNewsletter) && (
            <div>
              <h3 className="text-lg font-bold mb-6 font-inter">{settings.newsLetterTitle || "Newsletter"}</h3>
              <p className="text-neutral-400 mb-4 text-sm">
                {settings.newsLetterText || "Subscribe to receive updates, access to exclusive deals, and more."}
              </p>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="mb-4">
                  <div className="flex">
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem className="w-full">
                          <FormControl>
                            <Input
                              {...field}
                              placeholder={settings.newsLetterPlaceholder || "Your email address"}
                              className="px-4 py-3 rounded-l-md w-full focus:outline-none text-neutral-900 rounded-r-none"
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <Button 
                      type="submit" 
                      className="bg-accent-yellow text-primary px-4 py-3 rounded-r-md hover:bg-opacity-90 transition-all rounded-l-none"
                    >
                      <i className="fas fa-paper-plane"></i>
                    </Button>
                  </div>
                </form>
              </Form>
              <p className="text-neutral-500 text-xs">
                {settings.newsLetterDisclaimer || "By subscribing, you agree to our Privacy Policy and consent to receive updates from our company."}
              </p>
            </div>
          )}
        </div>
        
        <div className="mt-12 pt-8 border-t border-neutral-800 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-neutral-500 text-sm">
            &copy; {new Date().getFullYear()} {settings.siteName || "GrantedByFluffy"}. All rights reserved.
          </p>
          <div className="flex space-x-6 text-sm">
            {/* Ensure there's at least one donate link during transition */}
            <Link href="/donate" className="text-neutral-500 hover:text-accent-yellow transition-colors">
              Donate
            </Link>
            {settings.footerDonateLinks && Array.isArray(settings.footerDonateLinks) && settings.footerDonateLinks.map((link: {id: string, label: string, href: string}) => (
              <Link key={link.id} href={link.href} className="text-neutral-500 hover:text-accent-yellow transition-colors">
                {link.label}
              </Link>
            ))}
            <Link href="/privacy-policy" className="text-neutral-500 hover:text-accent-red transition-colors">
              Privacy Policy
            </Link>
            <Link href="/terms" className="text-neutral-500 hover:text-accent-red transition-colors">
              Terms of Service
            </Link>
            <Link href="/cookies" className="text-neutral-500 hover:text-accent-red transition-colors">
              Cookie Policy
            </Link>
          </div>
        </div>
      </div>
      
      {/* Background elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-72 h-72 rounded-full bg-accent-red opacity-5"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 rounded-full bg-accent-teal opacity-5"></div>
      </div>
    </footer>
  );
};

export default Footer;
