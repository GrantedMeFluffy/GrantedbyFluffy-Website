import React, { useState, useEffect } from "react";
import { cn } from "@/lib/utils";
import { Link } from "wouter";

const CookieConsent: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);
  
  useEffect(() => {
    // Check if user has already accepted or declined cookies
    const consent = localStorage.getItem("cookieConsent");
    
    if (!consent) {
      // Show cookie consent after a delay
      const timer = setTimeout(() => {
        setIsVisible(true);
      }, 2000);
      
      return () => clearTimeout(timer);
    }
  }, []);
  
  const handleAccept = () => {
    localStorage.setItem("cookieConsent", "accepted");
    setIsVisible(false);
  };
  
  const handleDecline = () => {
    localStorage.setItem("cookieConsent", "declined");
    setIsVisible(false);
  };
  
  if (!isVisible) return null;
  
  return (
    <div 
      className={cn(
        "fixed bottom-4 right-4 max-w-sm p-6 rounded-xl shadow-xl z-50",
        "bg-background/80 backdrop-blur-md border border-border",
        "transition-all duration-500 transform",
        isVisible ? "translate-y-0 opacity-100" : "translate-y-full opacity-0"
      )}
    >
      <div className="flex items-start mb-4">
        <div className="text-xl text-accent-yellow mr-3">
          <i className="fas fa-cookie-bite"></i>
        </div>
        <div>
          <h3 className="font-bold text-lg mb-2">Cookie Notice</h3>
          <p className="text-sm text-muted-foreground mb-4">
            We use cookies to enhance your experience on our website. By continuing to browse, you agree to our use of cookies.
          </p>
          <div className="flex flex-wrap gap-2">
            <button 
              onClick={handleAccept}
              className="px-4 py-2 bg-accent-yellow text-primary text-sm font-medium rounded-md hover:bg-opacity-90 transition-all"
            >
              Accept
            </button>
            <button 
              onClick={handleDecline}
              className="px-4 py-2 bg-transparent border border-border text-foreground text-sm font-medium rounded-md hover:bg-muted transition-all"
            >
              Decline
            </button>
            <Link href="/privacy-policy" className="text-sm text-accent-red hover:underline">
              Privacy Policy
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CookieConsent;
