import React from "react";
import { useTheme } from "./theme-provider";
import { cn } from "@/lib/utils";

interface ThemeToggleProps {
  className?: string;
}

const ThemeToggle: React.FC<ThemeToggleProps> = ({ className }) => {
  const { theme, setTheme } = useTheme();

  function toggleTheme() {
    setTheme(theme === "light" ? "dark" : "light");
  }

  return (
    <button
      onClick={toggleTheme}
      className={cn(
        "p-2 rounded-full bg-background/20 backdrop-blur-md hover:bg-muted transition-all duration-300",
        className
      )}
      aria-label="Toggle theme"
    >
      {theme === "light" ? (
        <i className="fas fa-moon text-accent-teal"></i>
      ) : (
        <i className="fas fa-sun text-accent-yellow"></i>
      )}
    </button>
  );
};

export default ThemeToggle;
