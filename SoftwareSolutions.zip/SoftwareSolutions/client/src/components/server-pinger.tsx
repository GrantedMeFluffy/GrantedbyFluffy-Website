import { useEffect, useRef } from 'react';

/**
 * A component that pings the server regularly to prevent it from going to sleep
 * This helps maintain 100% uptime in environments like Replit
 */
const ServerPinger = () => {
  const pingIntervalRef = useRef<number | null>(null);
  
  useEffect(() => {
    // Define the ping function
    const pingServer = async () => {
      try {
        await fetch('/healthz');
        console.log('Server ping successful');
      } catch (error) {
        console.error('Server ping failed:', error);
      }
    };
    
    // Call immediately on mount
    pingServer();
    
    // Set up interval to ping every 4 minutes
    // This is below the 5 minute idle timeout most platforms use
    pingIntervalRef.current = window.setInterval(pingServer, 4 * 60 * 1000);
    
    // Cleanup on unmount
    return () => {
      if (pingIntervalRef.current) {
        window.clearInterval(pingIntervalRef.current);
      }
    };
  }, []);
  
  // This component doesn't render anything
  return null;
};

export default ServerPinger;