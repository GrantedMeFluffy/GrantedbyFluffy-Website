import React, { useState, useEffect } from "react";
import { cn } from "@/lib/utils";

const Cursor: React.FC = () => {
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isPointer, setIsPointer] = useState(false);
  const [isVisible, setIsVisible] = useState(false);
  
  useEffect(() => {
    // Check if device has touch support - don't show custom cursor on touch devices
    if ('ontouchstart' in window) {
      return;
    }
    
    const updateCursorPosition = (e: MouseEvent) => {
      setPosition({ x: e.clientX, y: e.clientY });
      setIsVisible(true);
    };
    
    const updateCursorStyle = () => {
      const target = document.elementFromPoint(position.x, position.y);
      
      if (target) {
        // Check if the cursor is over a clickable element
        const isClickable = 
          target.tagName.toLowerCase() === 'a' || 
          target.tagName.toLowerCase() === 'button' ||
          target.closest('a') !== null || 
          target.closest('button') !== null ||
          target.classList.contains('cursor-pointer') ||
          target.closest('.cursor-pointer') !== null;
        
        setIsPointer(isClickable);
      }
    };
    
    const handleMouseLeave = () => {
      setIsVisible(false);
    };
    
    const handleMouseEnter = () => {
      setIsVisible(true);
    };
    
    document.addEventListener('mousemove', updateCursorPosition);
    document.addEventListener('mousemove', updateCursorStyle);
    document.addEventListener('mouseleave', handleMouseLeave);
    document.addEventListener('mouseenter', handleMouseEnter);
    
    return () => {
      document.removeEventListener('mousemove', updateCursorPosition);
      document.removeEventListener('mousemove', updateCursorStyle);
      document.removeEventListener('mouseleave', handleMouseLeave);
      document.removeEventListener('mouseenter', handleMouseEnter);
    };
  }, [position]);
  
  if (!isVisible) return null;
  
  return (
    <>
      <div 
        className={cn(
          "fixed pointer-events-none z-[9999] transform -translate-x-1/2 -translate-y-1/2 transition-all duration-100 ease-out",
          isPointer ? "w-8 h-8 bg-accent-red rounded-full opacity-60" : "w-6 h-6 border-2 border-black dark:border-white rounded-full opacity-70"
        )}
        style={{ 
          left: `${position.x}px`, 
          top: `${position.y}px`
        }}
      />
      <style jsx global>{`
        body, html {
          cursor: none !important;
        }
        
        * {
          cursor: none !important;
        }
      `}</style>
    </>
  );
};

export default Cursor;
