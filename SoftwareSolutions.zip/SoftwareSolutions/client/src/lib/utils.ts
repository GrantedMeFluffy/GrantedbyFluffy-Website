import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/**
 * Check if the current user is an admin
 * This is a client-side check used for basic UI rendering decisions
 * The server will still perform proper auth checks
 */
export function isAdmin(): boolean {
  // First check if there is a user in sessionStorage
  const userJson = sessionStorage.getItem('user');
  if (!userJson) return false;
  
  try {
    const user = JSON.parse(userJson);
    return user && user.isAdmin === true;
  } catch (error) {
    console.error('Error parsing user data from session storage:', error);
    return false;
  }
}
