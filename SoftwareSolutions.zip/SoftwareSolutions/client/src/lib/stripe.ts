import { loadStripe } from "@stripe/stripe-js";

// Make sure to call `loadStripe` outside of a component's render to avoid
// recreating the `Stripe` object on every render
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY || "");

export default stripePromise;

export const createPaymentIntent = async (productId: string, amount: number) => {
  try {
    const response = await fetch("/api/create-payment-intent", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ productId, amount }),
    });
    
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || "Failed to create payment intent");
    }
    
    return await response.json();
  } catch (error) {
    console.error("Error creating payment intent:", error);
    throw error;
  }
};

interface DonationMetadata {
  name?: string;
  email?: string;
  message?: string;
}

export const createDonation = async (
  amount: number,
  isRecurring: boolean = false,
  metadata: DonationMetadata = {}
) => {
  try {
    const response = await fetch("/api/create-donation", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        amount,
        isRecurring,
        metadata
      }),
    });
    
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || "Failed to create donation");
    }
    
    return await response.json();
  } catch (error) {
    console.error("Error creating donation:", error);
    throw error;
  }
};
