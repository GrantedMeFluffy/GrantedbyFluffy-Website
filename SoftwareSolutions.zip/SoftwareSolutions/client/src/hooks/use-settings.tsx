import React, { createContext, useContext, ReactNode } from 'react';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

// Default settings
const defaultSettings: Record<string, any> = {
  siteName: 'GrantedByFluffy',
  siteTagline: 'Software Development & Solutions',
  contactEmail: 'contact@grantedby.fluffy',
  contactPhone: '+1 (555) 123-4567',
  contactAddress: '123 Code Street\nDeveloper City, DC 10101',
  primaryColor: '#f97316',
  secondaryColor: '#10b981',
  heroTitle: 'Building Software That Makes a Difference',
  heroSubtitle: 'Custom software solutions for your business needs',
  heroButtonText: 'Get Started',
  aboutTitle: 'About GrantedByFluffy',
  aboutContent: 'GrantedByFluffy is a software development business that focuses on creating innovative, user-friendly applications tailored to your specific needs.',
  twitterUrl: 'https://twitter.com/grantedby.fluffy',
  githubUrl: 'https://github.com/grantedby.fluffy',
  linkedinUrl: 'https://linkedin.com/in/grantedby.fluffy',
};

// Create context
interface SettingsContextType {
  settings: Record<string, any>;
  isLoading: boolean;
}

const SettingsContext = createContext<SettingsContextType>({
  settings: defaultSettings,
  isLoading: false
});

// Provider component
export function SettingsProvider({ children }: { children: ReactNode }) {
  // Fetch settings from server
  const { data, isLoading } = useQuery({
    queryKey: ['/api/settings'],
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', `/api/settings?t=${Date.now()}`);
        if (!res.ok) {
          throw new Error('Failed to fetch settings');
        }
        return await res.json();
      } catch (error) {
        console.error('Error fetching settings:', error);
        return {};
      }
    },
    refetchOnWindowFocus: true,
    staleTime: 10 * 1000, // Consider data stale after 10 seconds
  });

  // Merge default settings with fetched settings
  const mergedSettings = {
    ...defaultSettings,
    ...(data || {})
  };

  return (
    <SettingsContext.Provider value={{ settings: mergedSettings, isLoading }}>
      {children}
    </SettingsContext.Provider>
  );
}

// Hook for using settings
export function useSettings() {
  const context = useContext(SettingsContext);
  if (!context) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
}