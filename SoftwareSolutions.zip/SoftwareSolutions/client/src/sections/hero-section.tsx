import React, { useEffect, useRef } from "react";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import { useSettings } from "@/hooks/use-settings";
import Logo from "@/components/logo";

const HeroSection: React.FC = () => {
  const typingRef = useRef<HTMLSpanElement>(null);
  const { settings } = useSettings();
  
  useEffect(() => {
    const phrases = ["Premium", "Innovative", "Robust", "Custom"];
    let currentPhraseIndex = 0;
    let currentCharIndex = 0;
    let isDeleting = false;
    let typingSpeed = 150;
    
    const type = () => {
      const currentPhrase = phrases[currentPhraseIndex];
      
      if (isDeleting) {
        if (typingRef.current) {
          typingRef.current.textContent = currentPhrase.substring(0, currentCharIndex - 1);
          currentCharIndex--;
        }
        typingSpeed = 50;
      } else {
        if (typingRef.current) {
          typingRef.current.textContent = currentPhrase.substring(0, currentCharIndex + 1);
          currentCharIndex++;
        }
        typingSpeed = 150;
      }
      
      if (!isDeleting && currentCharIndex === currentPhrase.length) {
        isDeleting = true;
        typingSpeed = 2000; // Pause at the end of word
      } else if (isDeleting && currentCharIndex === 0) {
        isDeleting = false;
        currentPhraseIndex = (currentPhraseIndex + 1) % phrases.length;
        typingSpeed = 500; // Pause before typing next word
      }
      
      setTimeout(type, typingSpeed);
    };
    
    const typingTimeout = setTimeout(type, 1000);
    
    return () => clearTimeout(typingTimeout);
  }, []);
  
  return (
    <section className="relative min-h-screen flex items-center justify-center pt-20 pb-16 px-4 overflow-hidden">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-black via-neutral-900 to-black opacity-90"></div>
        <img 
          src="https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1920" 
          alt="Software Development Workspace" 
          className="absolute inset-0 w-full h-full object-cover"
          style={{ zIndex: -1 }}
        />
      </div>
      
      <div className="container mx-auto relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div 
            className="text-center lg:text-left"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="mb-6 inline-block">
              <div className="w-16 h-1 bg-accent-red mb-6 mx-auto lg:mx-0"></div>
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold font-inter text-white leading-tight mb-6">
              {settings.heroTitle || (
                <>
                  <span className="text-white">Crafting </span>
                  <span ref={typingRef} className="text-accent-red"></span>
                  <span className="text-white"> Software</span>
                </>
              )}
            </h1>
            <p className="text-xl text-neutral-200 mb-8 max-w-2xl mx-auto lg:mx-0">
              {settings.heroSubtitle || "Innovative software solutions that transform your business operations and enhance user experiences."}
            </p>
            <div className="flex flex-wrap gap-4 justify-center lg:justify-start">
              <motion.a 
                href="#services" 
                className={cn(
                  "px-8 py-4 bg-accent-red text-white font-medium rounded-md", 
                  "hover:bg-opacity-90 transition-all duration-300 shadow-lg hover:shadow-xl",
                  "transform hover:-translate-y-1"
                )}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {settings.heroButtonText || "Explore Services"}
              </motion.a>
              <motion.a 
                href="#contact" 
                className={cn(
                  "px-8 py-4 bg-transparent border-2 border-white text-white font-medium rounded-md", 
                  "hover:bg-white hover:text-primary transition-all duration-300 shadow-lg hover:shadow-xl",
                  "transform hover:-translate-y-1"
                )}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Get in Touch
              </motion.a>
              <motion.a 
                href="/donate" 
                className={cn(
                  "px-8 py-4 bg-transparent border-2 border-accent-yellow text-accent-yellow font-medium rounded-md", 
                  "hover:bg-accent-yellow hover:text-black transition-all duration-300 shadow-lg hover:shadow-xl",
                  "transform hover:-translate-y-1"
                )}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Support Us
              </motion.a>
            </div>
          </motion.div>
          
          <motion.div 
            className="hidden lg:block"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ 
              duration: 0.8,
              delay: 0.3,
            }}
          >
            <motion.div 
              className="relative"
              animate={{ 
                y: [0, -10, 0],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                repeatType: 'loop',
              }}
            >
              <div className="absolute inset-0 bg-accent-teal rounded-full opacity-10 blur-2xl transform scale-110"></div>
              <Logo size="xl" className="w-80 h-80 mx-auto relative z-10" showText={false} />
            </motion.div>
          </motion.div>
        </div>
        
        <motion.div 
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-center"
          animate={{ 
            y: [0, 5, 0],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            repeatType: 'loop',
          }}
        >
          <a href="#about" className="text-white flex flex-col items-center opacity-70 hover:opacity-100 transition-opacity">
            <span className="mb-2">Scroll Down</span>
            <i className="fas fa-chevron-down"></i>
          </a>
        </motion.div>
      </div>
    </section>
  );
};

export default HeroSection;
