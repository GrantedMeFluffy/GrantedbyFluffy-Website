import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import { projects } from "@/../../server/schema";
import { useSettings } from "@/hooks/use-settings";

interface ProjectCardProps {
  project: any;
  isFlipped: boolean;
  onClick: () => void;
}

const ProjectCard: React.FC<ProjectCardProps> = ({ project, isFlipped, onClick }) => {
  return (
    <div 
      className="cursor-pointer group h-full"
      onClick={onClick}
      style={{ perspective: "1000px", height: "400px" }}
    >
      <motion.div
        className="relative w-full h-full"
        initial={false}
        animate={{ rotateY: isFlipped ? 180 : 0 }}
        transition={{ duration: 0.6 }}
        style={{ transformStyle: "preserve-3d" }}
      >
        {/* Front */}
        <div 
          className={cn(
            "absolute w-full h-full rounded-2xl overflow-hidden shadow-lg",
            "backface-hidden"
          )}
          style={{
            background: "rgba(255, 255, 255, 0.05)",
            backdropFilter: "blur(10px)",
            WebkitBackdropFilter: "blur(10px)",
            border: "1px solid rgba(255, 255, 255, 0.05)",
            backfaceVisibility: "hidden"
          }}
        >
          <div className="relative">
            <img 
              src={project.imageUrl} 
              alt={`Project: ${project.title}`} 
              className="w-full h-48 object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-50"></div>
            <div className="absolute bottom-4 left-4 text-white">
              <h3 className="font-bold text-lg">{project.title}</h3>
            </div>
          </div>
          <div className="p-6">
            <div className="flex flex-wrap gap-2 mb-4">
              {project.technologies.map((tech: string, index: number) => (
                <span key={index} className="text-xs bg-neutral-200 px-2 py-1 rounded">
                  {tech}
                </span>
              ))}
            </div>
            <p className="text-neutral-700 text-sm">
              {project.description}
            </p>
            <div className="mt-4 flex items-center text-accent-red font-medium">
              <span>View Details</span>
              <i className="fas fa-arrow-right ml-2 transform group-hover:translate-x-1 transition-transform"></i>
            </div>
          </div>
        </div>
        
        {/* Back */}
        <div 
          className={cn(
            "absolute w-full h-full rounded-2xl overflow-hidden shadow-lg p-6",
            "backface-hidden"
          )}
          style={{
            background: "rgba(255, 255, 255, 0.05)",
            backdropFilter: "blur(10px)",
            WebkitBackdropFilter: "blur(10px)",
            border: "1px solid rgba(255, 255, 255, 0.05)",
            transform: "rotateY(180deg)",
            backfaceVisibility: "hidden"
          }}
        >
          <h3 className="font-bold text-lg mb-4">{project.title}</h3>
          <h4 className="font-bold text-sm mb-2">Project Highlights:</h4>
          <ul className="text-sm space-y-2 mb-6">
            {project.highlights.map((highlight: string, index: number) => (
              <li key={index} className="flex items-start">
                <i className="fas fa-check-circle text-accent-teal mt-1 mr-2"></i>
                <span>{highlight}</span>
              </li>
            ))}
          </ul>
          <div className="mt-6">
            <a 
              href="#contact" 
              className="inline-block px-4 py-2 bg-accent-red text-white rounded-md text-sm"
            >
              Request Similar Solution
            </a>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

const PortfolioSection: React.FC = () => {
  const [flippedCards, setFlippedCards] = useState<{ [key: string]: boolean }>({});
  const { settings } = useSettings();
  
  const toggleCard = (projectId: string) => {
    setFlippedCards(prev => ({
      ...prev,
      [projectId]: !prev[projectId]
    }));
  };
  
  // Function to render the appropriate projects based on settings
  const renderProjects = () => {
    // Check if we have dynamic projects from settings
    if (settings.dynamicProjects && settings.dynamicProjects.length > 0) {
      return settings.dynamicProjects.map((project: any, index: number) => (
        <motion.div
          key={project.id}
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.7, delay: 0.1 * index }}
        >
          <ProjectCard
            project={project}
            isFlipped={!!flippedCards[project.id]}
            onClick={() => toggleCard(project.id)}
          />
        </motion.div>
      ));
    }
    
    // Check if we have legacy projects from settings
    if (settings.project1Title || settings.project2Title || settings.project3Title) {
      return (
        <>
          {/* Project 1 */}
          {settings.project1Title && (
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.7, delay: 0.1 }}
            >
              <ProjectCard
                project={{
                  id: "custom-1",
                  title: settings.project1Title,
                  description: settings.project1Description || "A full-featured online store with inventory management and payment processing.",
                  imageUrl: settings.project1Image || "https://images.unsplash.com/photo-1563986768609-322da13575f3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
                  technologies: ["React", "Node.js", "Stripe"],
                  highlights: ["Secure payment processing", "Real-time inventory management", "Customer accounts"]
                }}
                isFlipped={!!flippedCards["custom-1"]}
                onClick={() => toggleCard("custom-1")}
              />
            </motion.div>
          )}
          
          {/* Project 2 */}
          {settings.project2Title && (
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.7, delay: 0.2 }}
            >
              <ProjectCard
                project={{
                  id: "custom-2",
                  title: settings.project2Title,
                  description: settings.project2Description || "A productivity application for teams with real-time collaboration features.",
                  imageUrl: settings.project2Image || "https://images.unsplash.com/photo-1512758017271-d7b84c2113f1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
                  technologies: ["React", "Firebase", "WebSockets"],
                  highlights: ["Real-time collaboration", "Task management", "Team dashboards"]
                }}
                isFlipped={!!flippedCards["custom-2"]}
                onClick={() => toggleCard("custom-2")}
              />
            </motion.div>
          )}
          
          {/* Project 3 */}
          {settings.project3Title && (
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.7, delay: 0.3 }}
            >
              <ProjectCard
                project={{
                  id: "custom-3",
                  title: settings.project3Title,
                  description: settings.project3Description || "Interactive data visualization dashboard for business intelligence.",
                  imageUrl: settings.project3Image || "https://images.unsplash.com/photo-1551288049-bebda4e38f71?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
                  technologies: ["D3.js", "React", "Express"],
                  highlights: ["Custom data visualizations", "Interactive filters", "Data export"]
                }}
                isFlipped={!!flippedCards["custom-3"]}
                onClick={() => toggleCard("custom-3")}
              />
            </motion.div>
          )}
        </>
      );
    }
    
    // Fallback to default projects if no settings are defined
    return projects.map((project, index) => (
      <motion.div
        key={project.id}
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-100px" }}
        transition={{ duration: 0.7, delay: 0.1 * index }}
      >
        <ProjectCard
          project={project}
          isFlipped={!!flippedCards[project.id]}
          onClick={() => toggleCard(project.id)}
        />
      </motion.div>
    ));
  };
  
  return (
    <section id="portfolio" className="py-20 relative overflow-hidden">
      <div className="container mx-auto px-4">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.7 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold font-inter mb-4">
            {settings.portfolioTitle || "Featured"} <span className="text-accent-red">Projects</span>
          </h2>
          <p className="max-w-2xl mx-auto text-neutral-700">
            {settings.portfolioDescription || "A showcase of my most impactful software solutions across various industries"}
          </p>
          <div className="w-16 h-1 bg-accent-red mx-auto mt-4"></div>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {renderProjects()}
        </div>
        
        <motion.div 
          className="text-center"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.7, delay: 0.3 }}
        >
          <a 
            href="#contact" 
            className={cn(
              "px-8 py-4 bg-accent-red text-white font-medium rounded-md",
              "hover:bg-opacity-90 transition-all duration-300 shadow-lg hover:shadow-xl",
              "transform hover:-translate-y-1"
            )}
          >
            See Full Portfolio
          </a>
        </motion.div>
      </div>
    </section>
  );
};

export default PortfolioSection;