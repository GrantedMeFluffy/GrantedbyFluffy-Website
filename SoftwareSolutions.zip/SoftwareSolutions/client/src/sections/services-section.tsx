import React from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { services } from "@/../../server/schema";
import { useSettings } from "@/hooks/use-settings";

// Define a Service type interface
interface Service {
  id: string;
  title: string;
  description: string;
  icon?: string;
  features?: string[];
}

const ServicesSection: React.FC = () => {
  const { settings } = useSettings();
  
  // Function to render a single service card
  const renderServiceCard = (service: Service, index: number) => {
    return (
      <motion.div 
        key={service.id}
        className="p-8 rounded-2xl relative overflow-hidden group"
        style={{
          background: "rgba(255, 255, 255, 0.05)",
          backdropFilter: "blur(10px)",
          WebkitBackdropFilter: "blur(10px)",
          border: "1px solid rgba(255, 255, 255, 0.05)"
        }}
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-100px" }}
        transition={{ duration: 0.7, delay: 0.1 * index }}
        whileHover={{ 
          y: -5,
          transition: { duration: 0.3 } 
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-br from-accent-teal to-accent-red opacity-0 group-hover:opacity-10 transition-opacity duration-500"></div>
        <div className="text-accent-teal mb-6 text-4xl">
          <i className={`fas fa-${service.icon || 'code'}`}></i>
        </div>
        <h3 className="text-xl font-bold mb-3 font-inter">{service.title}</h3>
        <p className="text-neutral-300 mb-4">
          {service.description}
        </p>
        {service.features && service.features.length > 0 && (
          <ul className="text-sm space-y-2 mb-6">
            {service.features.map((feature, featureIndex) => (
              <li key={featureIndex} className="flex items-center">
                <i className="fas fa-check text-accent-yellow mr-2"></i>
                <span>{feature}</span>
              </li>
            ))}
          </ul>
        )}
        <a 
          href="#contact" 
          className="inline-block text-accent-teal hover:text-accent-red transition-colors font-medium group"
        >
          Learn More
          <i className="fas fa-arrow-right ml-1 transform group-hover:translate-x-1 transition-transform"></i>
        </a>
      </motion.div>
    );
  };
  
  // Function to render the services based on settings
  const renderServices = () => {
    // If dynamic services are available, use them
    if (settings.dynamicServices && settings.dynamicServices.length > 0) {
      return settings.dynamicServices.map((service: Service, index: number) => 
        renderServiceCard(service, index)
      );
    }
    
    // If legacy individual service settings are available, use them
    if (settings.service1Title || settings.service2Title || settings.service3Title) {
      const legacyServices = [];
      
      if (settings.service1Title) {
        legacyServices.push({
          id: 'legacy-1',
          title: settings.service1Title,
          description: settings.service1Description || "Bespoke software solutions designed specifically for your business requirements.",
          icon: 'code'
        });
      }
      
      if (settings.service2Title) {
        legacyServices.push({
          id: 'legacy-2',
          title: settings.service2Title,
          description: settings.service2Description || "Responsive, scalable web applications with modern technologies.",
          icon: 'laptop-code'
        });
      }
      
      if (settings.service3Title) {
        legacyServices.push({
          id: 'legacy-3',
          title: settings.service3Title,
          description: settings.service3Description || "Robust APIs and seamless integration with third-party services.",
          icon: 'cogs'
        });
      }
      
      return legacyServices.map((service, index) => 
        renderServiceCard(service, index)
      );
    }
    
    // Fallback to default services
    return services.map((service, index) => 
      renderServiceCard(service, index)
    );
  };
  
  return (
    <section id="services" className="py-20 bg-primary text-white relative overflow-hidden">
      <div className="container mx-auto px-4 relative z-10">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.7 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold font-inter mb-4">
            {settings.servicesTitle || "Our"} <span className="text-accent-teal">Services</span>
          </h2>
          <p className="max-w-2xl mx-auto text-neutral-300">
            {settings.servicesIntro || "Comprehensive software solutions tailored to your unique business needs"}
          </p>
          <div className="w-16 h-1 bg-accent-teal mx-auto mt-4"></div>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {renderServices()}
        </div>
        
        <motion.div 
          className="mt-16 text-center"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.7, delay: 0.5 }}
        >
          <a 
            href="#contact" 
            className={cn(
              "px-8 py-4 bg-accent-teal text-primary font-medium rounded-md inline-flex items-center",
              "hover:bg-opacity-90 transition-all duration-300 shadow-lg hover:shadow-xl",
              "transform hover:-translate-y-1"
            )}
          >
            <span>Discuss Your Project</span>
            <i className="fas fa-arrow-right ml-2"></i>
          </a>
        </motion.div>
      </div>
      
      {/* Background elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-72 h-72 rounded-full bg-accent-teal opacity-5"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 rounded-full bg-accent-red opacity-5"></div>
        <div className="absolute top-1/3 right-1/4 w-48 h-48 rounded-full bg-accent-yellow opacity-5"></div>
      </div>
    </section>
  );
};

export default ServicesSection;