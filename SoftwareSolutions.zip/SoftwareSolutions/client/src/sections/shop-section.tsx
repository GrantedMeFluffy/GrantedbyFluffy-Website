import React from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { useSettings } from "@/hooks/use-settings";
import { Button } from "@/components/ui/button";
import { Link, useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { loadStripe } from "@stripe/stripe-js";

interface FeaturedProduct {
  id: string;
  name: string;
  description: string;
  imageUrl: string;
  price: number;
  discountPrice?: number;
  featured?: boolean;
  stripePriceId?: string;
}

// Load Stripe outside of component render to avoid recreating the Stripe object
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY || "");

const ShopSection: React.FC = () => {
  const { settings } = useSettings();
  const { toast } = useToast();
  const [location, setLocation] = useLocation();
  
  // Get featured products from settings, with fallback
  const featuredProducts = settings.featuredProducts || [];
  
  // Show section even if there are no featured products
  // This allows users to see the section and encourages adding products
  // if (!featuredProducts || featuredProducts.length === 0) {
  //   return null;
  // }
  
  // Handle direct checkout with Stripe
  const handleCheckout = async (product: FeaturedProduct) => {
    if (!product.stripePriceId) {
      toast({
        title: "Checkout Error",
        description: "This product doesn't have a valid Stripe price ID configured.",
        variant: "destructive",
      });
      return;
    }
    
    try {
      // Redirect to Stripe Checkout
      const stripe = await stripePromise;
      if (!stripe) {
        throw new Error("Failed to load Stripe");
      }
      
      // Create checkout session on the server
      const response = await fetch("/api/create-checkout-session", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          priceId: product.stripePriceId,
          productName: product.name,
          successUrl: `${window.location.origin}/checkout-success`,
          cancelUrl: `${window.location.origin}/#shop`,
        }),
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Failed to create checkout session");
      }
      
      const session = await response.json();
      
      // Redirect to Stripe Checkout
      const result = await stripe.redirectToCheckout({
        sessionId: session.id,
      });
      
      if (result.error) {
        throw new Error(result.error.message || "Failed to redirect to Stripe Checkout");
      }
    } catch (error: any) {
      console.error("Error during checkout:", error);
      toast({
        title: "Checkout Error",
        description: error.message || "An error occurred during checkout. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <section id="shop" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.7 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            {settings.shopTitle || "Software Products"}
          </h2>
          <p className="max-w-2xl mx-auto text-muted-foreground">
            {settings.shopDescription || "Explore my collection of premium software products designed to enhance productivity and workflow."}
          </p>
          <div className="w-16 h-1 bg-primary mx-auto mt-4"></div>
        </motion.div>

        {/* Featured Products Section */}
        <div className="mb-20">
          <motion.h3 
            className="text-2xl font-semibold text-center mb-10"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            {settings.featuredProductsTitle || "Featured Products"}
            {settings.featuredProductsDescription && (
              <span className="block text-base font-normal mt-2 text-muted-foreground">
                {settings.featuredProductsDescription}
              </span>
            )}
          </motion.h3>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredProducts.length > 0 ? (
              featuredProducts.map((product: FeaturedProduct, index: number) => (
                <motion.div
                  key={product.id}
                  className="bg-card rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow"
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-100px" }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  whileHover={{ y: -5, transition: { duration: 0.3 } }}
                >
                  <div className="h-48 bg-muted overflow-hidden">
                    {product.imageUrl ? (
                      <img 
                        src={product.imageUrl} 
                        alt={product.name} 
                        className="w-full h-full object-cover transition-transform hover:scale-105" 
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-gradient-to-r from-primary-300 to-primary-600">
                        <span className="text-white text-lg font-medium">Product Image</span>
                      </div>
                    )}
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-semibold mb-2">{product.name}</h3>
                    <p className="text-muted-foreground mb-4 line-clamp-2">{product.description}</p>
                    
                    <div className="flex justify-between items-center">
                      <div className="flex items-end gap-2">
                        {product.discountPrice ? (
                          <>
                            <span className="text-xl font-bold text-primary">${product.discountPrice.toFixed(2)}</span>
                            <span className="text-muted-foreground line-through text-sm">${product.price.toFixed(2)}</span>
                          </>
                        ) : (
                          <span className="text-xl font-bold text-primary">${product.price.toFixed(2)}</span>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex justify-between items-center mt-4 gap-2">
                      <Button 
                        variant="default" 
                        size="sm"
                        className="flex-1"
                        onClick={() => handleCheckout(product)}
                        disabled={!product.stripePriceId}
                      >
                        Buy Now
                      </Button>
                      <Link href={`/products/${product.id}`}>
                        <Button variant="secondary" size="sm">
                          Details
                        </Button>
                      </Link>
                    </div>
                  </div>
                </motion.div>
              ))
            ) : (
              // Show message when no products are available
              <div className="col-span-1 md:col-span-2 lg:col-span-3 text-center py-12 border-2 border-dashed border-muted rounded-xl">
                <div className="flex flex-col items-center justify-center space-y-4">
                  <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-semibold">No Products Available</h3>
                  <p className="text-muted-foreground max-w-md">
                    Products can be added through the admin settings panel. Once added, they will appear here for customers to purchase.
                  </p>
                </div>
              </div>
            )}
          </div>
          
          <div className="text-center mt-12">
            <Link href="#contact">
              <Button 
                className="px-6 py-2.5"
                variant="default"
                size="lg"
              >
                {settings.shopCTA || "Contact for More Products"}
              </Button>
            </Link>
          </div>
        </div>

        {/* Custom Package Section */}
        <motion.div 
          className="bg-muted rounded-2xl p-10 mt-16 relative overflow-hidden"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.7 }}
        >
          <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent"></div>
          <div className="relative z-10 max-w-3xl mx-auto text-center">
            <h3 className="text-2xl md:text-3xl font-bold mb-4">
              {settings.customPackageTitle || "Custom Software Packages"}
            </h3>
            <p className="text-muted-foreground mb-8">
              {settings.customPackageDescription || "Need a tailored solution? We create custom software packages designed specifically for your business needs and challenges."}
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
              <div className="bg-background/80 backdrop-blur p-5 rounded-lg">
                <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-primary mb-3 mx-auto">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clipRule="evenodd" />
                  </svg>
                </div>
                <p className="font-medium">{settings.customPackageFeature1 || "Custom feature development"}</p>
              </div>
              
              <div className="bg-background/80 backdrop-blur p-5 rounded-lg">
                <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-primary mb-3 mx-auto">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M13 7H7v6h6V7z" />
                    <path fillRule="evenodd" d="M7 2a1 1 0 012 0v1h2V2a1 1 0 112 0v1h2a2 2 0 012 2v2h1a1 1 0 110 2h-1v2h1a1 1 0 110 2h-1v2a2 2 0 01-2 2h-2v1a1 1 0 11-2 0v-1H9v1a1 1 0 11-2 0v-1H5a2 2 0 01-2-2v-2H2a1 1 0 110-2h1V9H2a1 1 0 010-2h1V5a2 2 0 012-2h2V2zM5 5h10v10H5V5z" clipRule="evenodd" />
                  </svg>
                </div>
                <p className="font-medium">{settings.customPackageFeature2 || "Integration with existing systems"}</p>
              </div>
              
              <div className="bg-background/80 backdrop-blur p-5 rounded-lg">
                <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-primary mb-3 mx-auto">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                  </svg>
                </div>
                <p className="font-medium">{settings.customPackageFeature3 || "Ongoing support and maintenance"}</p>
              </div>
            </div>
            
            <Link href="/contact">
              <Button 
                className="px-8 py-3"
                size="lg"
              >
                {settings.customPackageButtonText || "Request Custom Package"}
              </Button>
            </Link>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default ShopSection;