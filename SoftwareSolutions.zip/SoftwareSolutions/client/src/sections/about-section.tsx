import React from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { useSettings } from "@/hooks/use-settings";

const AboutSection: React.FC = () => {
  const { settings } = useSettings();
  return (
    <section id="about" className="py-20 relative overflow-hidden">
      <div className="container mx-auto px-4">
        <motion.div 
          className="rounded-3xl p-12 max-w-6xl mx-auto relative overflow-hidden shadow-2xl"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.7 }}
          style={{
            background: "rgba(255, 255, 255, 0.05)",
            backdropFilter: "blur(10px)",
            WebkitBackdropFilter: "blur(10px)",
            border: "1px solid rgba(255, 255, 255, 0.1)"
          }}
        >
          <div className="absolute top-0 right-0 -mr-20 -mt-20 w-64 h-64 rounded-full bg-accent-teal opacity-10 blur-3xl"></div>
          <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-64 h-64 rounded-full bg-accent-red opacity-10 blur-3xl"></div>
          
          <div className="text-center mb-12">
            <motion.h2 
              className="text-3xl md:text-4xl font-bold font-inter mb-4"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.7, delay: 0.2 }}
            >
              {settings.aboutTitle ? settings.aboutTitle : (
                <span dangerouslySetInnerHTML={{ __html: `About <span class="text-accent-red">${settings.siteName || "GrantedByFluffy"}</span>` }} />
              )}
            </motion.h2>
            <motion.div 
              className="w-16 h-1 bg-accent-teal mx-auto"
              initial={{ width: 0 }}
              whileInView={{ width: 64 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.7, delay: 0.4 }}
            ></motion.div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <motion.p 
                className="text-lg mb-6 text-foreground"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.7, delay: 0.5 }}
              >
                {settings.aboutText || "GrantedByFluffy is a premium software development studio founded on the principles of excellence, innovation, and user-centered design. As a solo developer, I bring a personal touch to every project, ensuring meticulous attention to detail and seamless communication."}
              </motion.p>
              <motion.p 
                className="text-lg mb-6 text-foreground"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.7, delay: 0.6 }}
              >
                {settings.aboutSubtext || "My approach combines technical expertise with creative problem-solving to deliver software solutions that not only meet your business requirements but exceed your expectations in functionality and user experience."}
              </motion.p>
              <motion.div 
                className="mt-8"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.7, delay: 0.7 }}
              >
                <h3 className="text-xl font-bold mb-4 font-inter">Core Values</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-start">
                    <div className="mr-3 text-accent-teal">
                      <i className="fas fa-check-circle text-xl"></i>
                    </div>
                    <div>
                      <h4 className="font-bold">Quality</h4>
                      <p className="text-sm text-muted-foreground">Uncompromising attention to detail</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="mr-3 text-accent-teal">
                      <i className="fas fa-check-circle text-xl"></i>
                    </div>
                    <div>
                      <h4 className="font-bold">Innovation</h4>
                      <p className="text-sm text-muted-foreground">Cutting-edge solutions</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="mr-3 text-accent-teal">
                      <i className="fas fa-check-circle text-xl"></i>
                    </div>
                    <div>
                      <h4 className="font-bold">Transparency</h4>
                      <p className="text-sm text-muted-foreground">Clear communication throughout</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="mr-3 text-accent-teal">
                      <i className="fas fa-check-circle text-xl"></i>
                    </div>
                    <div>
                      <h4 className="font-bold">Adaptability</h4>
                      <p className="text-sm text-muted-foreground">Flexible to changing needs</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
            
            <motion.div 
              className="relative"
              initial={{ opacity: 0, x: 50, rotate: 3 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.7, delay: 0.8 }}
            >
              <div className="p-1 border-2 border-accent-teal rounded-2xl overflow-hidden transform rotate-3 hover:rotate-0 transition-transform duration-500">
                <img 
                  src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800" 
                  alt="Software Developer Workspace" 
                  className="rounded-xl"
                />
              </div>
              <motion.div 
                className="absolute -bottom-5 -left-5 p-4 rounded-lg shadow-xl transform -rotate-6 hover:rotate-0 transition-transform duration-500"
                style={{
                  background: "rgba(255, 255, 255, 0.1)",
                  backdropFilter: "blur(10px)",
                  WebkitBackdropFilter: "blur(10px)",
                  border: "1px solid rgba(255, 255, 255, 0.1)"
                }}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.7, delay: 1 }}
              >
                <div className="flex items-center">
                  <div className="rounded-full bg-status-success w-3 h-3 mr-2"></div>
                  <span className="text-sm font-medium">{settings.yearsExperience || "7+"} Years of Experience</span>
                </div>
              </motion.div>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default AboutSection;
