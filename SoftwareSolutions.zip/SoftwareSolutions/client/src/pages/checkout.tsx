import React, { useEffect, useState } from 'react';
import { useRoute, Link } from 'wouter';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import Logo from '@/components/logo';
import { Helmet } from 'react-helmet-async';
import { loadStripe } from '@stripe/stripe-js';
import { Elements, PaymentElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { createPaymentIntent } from '@/lib/stripe';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { useQuery } from '@tanstack/react-query';

// Check for Stripe public key
if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  console.warn('Missing Stripe public key. Checkout will not function properly.');
}

// Load Stripe outside of component to prevent recreating instance on each render
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY || '');

const CheckoutForm: React.FC<{ productName: string }> = ({ productName }) => {
  const stripe = useStripe();
  const elements = useElements();
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!stripe || !elements) {
      return;
    }
    
    setIsProcessing(true);
    
    try {
      const { error } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: window.location.origin,
        },
      });
      
      if (error) {
        toast({
          title: 'Payment Failed',
          description: error.message || 'An error occurred during payment',
          variant: 'destructive',
        });
      } else {
        toast({
          title: 'Payment Successful',
          description: 'Thank you for your purchase!',
        });
      }
    } catch (err) {
      toast({
        title: 'Error',
        description: 'An unexpected error occurred',
        variant: 'destructive',
      });
    } finally {
      setIsProcessing(false);
    }
  };
  
  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <PaymentElement />
      
      <Button
        type="submit"
        disabled={!stripe || isProcessing}
        className="w-full py-4 bg-accent-teal text-primary font-medium hover:bg-opacity-90 transition-all"
      >
        {isProcessing ? (
          <span className="flex items-center">
            <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            Processing...
          </span>
        ) : (
          <span className="flex items-center justify-center">
            <i className="fas fa-lock mr-2"></i>
            Pay Now
          </span>
        )}
      </Button>
    </form>
  );
};

const Checkout: React.FC = () => {
  const [match, params] = useRoute('/checkout/:productId');
  const [clientSecret, setClientSecret] = useState('');
  const { toast } = useToast();
  
  // Fetch product from the database
  const { data: product, isLoading: isProductLoading, error: productError } = useQuery({
    queryKey: ['/api/products', params?.productId],
    queryFn: async () => {
      if (!params?.productId) throw new Error('No product ID provided');
      const response = await fetch(`/api/products/${params.productId}`);
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to fetch product');
      }
      return response.json();
    },
    enabled: !!params?.productId,
  });
  
  // Create payment intent when product is loaded
  useEffect(() => {
    const initializePayment = async () => {
      if (!product) return;
      
      try {
        // Create payment intent
        const { clientSecret } = await createPaymentIntent(product.id, product.price);
        setClientSecret(clientSecret);
      } catch (error) {
        toast({
          title: 'Payment Error',
          description: error instanceof Error ? error.message : 'Failed to initialize payment',
          variant: 'destructive',
        });
      }
    };
    
    if (product) {
      initializePayment();
    }
  }, [product, toast]);
  
  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="animate-spin w-12 h-12 border-4 border-primary border-t-transparent rounded-full" aria-label="Loading"/>
      </div>
    );
  }
  
  if (!product) {
    return (
      <div className="h-screen flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Product Not Found</CardTitle>
            <CardDescription>The requested product could not be found.</CardDescription>
          </CardHeader>
          <CardFooter>
            <Link href="/">
              <a className="inline-block text-accent-red hover:underline">
                Return to Home
              </a>
            </Link>
          </CardFooter>
        </Card>
      </div>
    );
  }
  
  return (
    <>
      <Helmet>
        <title>Checkout - {product.name} | GrantedByFluffy</title>
      </Helmet>
      
      <div className="min-h-screen bg-neutral-50 py-12 px-4">
        <div className="container mx-auto max-w-4xl">
          <div className="mb-8 text-center">
            <Link href="/">
              <a className="inline-block">
                <Logo size="lg" />
              </a>
            </Link>
          </div>
          
          <Card className="shadow-xl">
            <CardHeader>
              <CardTitle className="text-2xl">Checkout</CardTitle>
              <CardDescription>Complete your purchase for {product.name}</CardDescription>
            </CardHeader>
            
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <h3 className="text-lg font-bold mb-4">Order Summary</h3>
                  
                  <div className="bg-background p-6 rounded-lg mb-4">
                    <div className="flex items-start space-x-4">
                      <div className="flex-shrink-0 w-16 h-16 bg-neutral-200 rounded-md overflow-hidden">
                        <img 
                          src={product.imageUrl}
                          alt={product.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      
                      <div className="flex-1">
                        <h4 className="font-bold">{product.name}</h4>
                        <div className="flex flex-wrap gap-2 my-2">
                          {product.tags.map((tag: string) => (
                            <span key={tag} className="text-xs bg-neutral-200 px-2 py-1 rounded">
                              {tag}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                    
                    <div className="border-t border-border my-4 pt-4">
                      <div className="flex justify-between mb-2">
                        <span>Price:</span>
                        <div className="text-right">
                          <span className="font-bold">${(product.price / 100).toFixed(2)}</span>
                          {product.discountPrice && (
                            <span className="text-muted-foreground line-through ml-2">
                              ${(product.discountPrice / 100).toFixed(2)}
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="flex justify-between font-bold text-lg mt-4">
                        <span>Total:</span>
                        <span>${(product.price / 100).toFixed(2)}</span>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-bold mb-4">Payment Details</h3>
                  
                  {clientSecret ? (
                    <Elements
                      stripe={stripePromise}
                      options={{
                        clientSecret,
                        appearance: {
                          theme: 'stripe',
                          variables: {
                            colorPrimary: '#4ECDC4',
                            colorBackground: '#ffffff',
                            colorText: '#212529',
                          },
                        },
                      }}
                    >
                      <CheckoutForm productName={product.name} />
                    </Elements>
                  ) : (
                    <div className="p-8 text-center">
                      <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
                      <p>Initializing payment...</p>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
            
            <CardFooter className="flex justify-between border-t border-border pt-6">
              <Link href="/#shop">
                <a className="text-accent-red hover:underline">
                  <i className="fas fa-arrow-left mr-2"></i>
                  Back to Shop
                </a>
              </Link>
              
              <p className="text-sm text-muted-foreground">
                <i className="fas fa-shield-alt mr-2"></i>
                Secure checkout powered by Stripe
              </p>
            </CardFooter>
          </Card>
        </div>
      </div>
    </>
  );
};

export default Checkout;
