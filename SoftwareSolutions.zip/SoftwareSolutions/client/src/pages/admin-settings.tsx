import { useEffect, useState, useCallback } from 'react';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, Save } from 'lucide-react';
import { Redirect } from 'wouter';
import { DynamicServicesManager } from '@/components/admin/dynamic-services-manager';
import { DynamicProductsManager } from '@/components/admin/dynamic-products-manager';
import { FooterQuickLinksManager } from '@/components/admin/footer-quick-links-manager';
import { FooterServicesLinksManager } from '@/components/admin/footer-services-links-manager';
import { FooterLinksManager } from '@/components/admin/footer-links-manager';

// Define setting sections and their respective fields
const WEBSITE_SETTINGS = {
  general: {
    title: 'General Settings',
    description: 'Basic website information',
    fields: [
      { key: 'siteName', label: 'Website Name', type: 'text', defaultValue: 'GrantedByFluffy' },
      { key: 'siteTagline', label: 'Tagline', type: 'text', defaultValue: 'Software Development & Solutions' },
      { key: 'siteDescription', label: 'Meta Description', type: 'textarea', defaultValue: 'Software development services by GrantedByFluffy, delivering innovative solutions and quality code.' },
    ]
  },
  contactInfo: {
    title: 'Contact Information',
    description: 'How visitors can reach you',
    fields: [
      { key: 'contactEmail', label: 'Email Address', type: 'text', defaultValue: 'contact@grantedby.fluffy' },
      { key: 'contactPhone', label: 'Phone Number', type: 'text', defaultValue: '+1 (555) 123-4567' },
      { key: 'contactAddress', label: 'Business Address', type: 'textarea', defaultValue: '123 Code Street\nDeveloper City, DC 10101' },
    ]
  },
  appearance: {
    title: 'Site Appearance',
    description: 'Customize how your website looks',
    fields: [
      { key: 'primaryColor', label: 'Primary Color', type: 'color', defaultValue: '#f97316' },
      { key: 'secondaryColor', label: 'Secondary Color', type: 'color', defaultValue: '#10b981' },
      { key: 'logoText', label: 'Logo Text', type: 'text', defaultValue: 'GrantedByFluffy' },
    ]
  },
  content: {
    title: 'Homepage Content',
    description: 'Customize your homepage sections',
    fields: [
      { key: 'heroTitle', label: 'Hero Title', type: 'text', defaultValue: 'Building Software That Makes a Difference' },
      { key: 'heroSubtitle', label: 'Hero Subtitle', type: 'text', defaultValue: 'Custom software solutions for your business needs' },
      { key: 'heroButtonText', label: 'Hero Button Text', type: 'text', defaultValue: 'Get Started' },
      { key: 'heroImage', label: 'Hero Background Image URL', type: 'text', defaultValue: 'https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1920' },
    ]
  },
  about: {
    title: 'About Section',
    description: 'Information about you and your business',
    fields: [
      { key: 'aboutTitle', label: 'About Section Title', type: 'text', defaultValue: 'About GrantedByFluffy' },
      { key: 'aboutText', label: 'First Paragraph', type: 'textarea', defaultValue: 'GrantedByFluffy is a premium software development studio founded on the principles of excellence, innovation, and user-centered design. As a solo developer, I bring a personal touch to every project, ensuring meticulous attention to detail and seamless communication.' },
      { key: 'aboutSubtext', label: 'Second Paragraph', type: 'textarea', defaultValue: 'My approach combines technical expertise with creative problem-solving to deliver software solutions that not only meet your business requirements but exceed your expectations in functionality and user experience.' },
      { key: 'yearsExperience', label: 'Years of Experience', type: 'text', defaultValue: '7+' },
      { key: 'aboutImage', label: 'About Image URL', type: 'text', defaultValue: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800' },
    ]
  },
  services: {
    title: 'Services Section',
    description: 'Services you offer to clients',
    fields: [
      { key: 'servicesTitle', label: 'Services Section Title', type: 'text', defaultValue: 'My Services' },
      { key: 'servicesIntro', label: 'Services Introduction', type: 'textarea', defaultValue: 'I offer a range of software development services tailored to your business needs.' },
      { key: 'dynamicServices', label: 'Services', type: 'dynamicServices', defaultValue: [
        {
          id: 'service-1',
          title: 'Custom Software Development',
          description: 'Bespoke software solutions designed specifically for your business requirements.',
          icon: 'code'
        },
        {
          id: 'service-2',
          title: 'Web Application Development',
          description: 'Responsive, scalable web applications with modern technologies.',
          icon: 'laptop-code'
        },
        {
          id: 'service-3',
          title: 'API Development & Integration',
          description: 'Robust APIs and seamless integration with third-party services.',
          icon: 'cogs'
        }
      ]},
    ]
  },

  shop: {
    title: 'Shop Section',
    description: 'Configuration for your product shop',
    fields: [
      { key: 'shopTitle', label: 'Shop Section Title', type: 'text', defaultValue: 'Software Products' },
      { key: 'shopDescription', label: 'Shop Introduction', type: 'textarea', defaultValue: 'Explore my collection of premium software products designed to enhance productivity and workflow.' },
      { key: 'featuredProductsTitle', label: 'Featured Products Title', type: 'text', defaultValue: 'Featured Products' },
      { key: 'featuredProductsDescription', label: 'Featured Products Subtitle', type: 'text', defaultValue: 'Popular software solutions handcrafted with care' },
      { key: 'featuredProducts', label: 'Homepage Featured Products', type: 'dynamicProducts', defaultValue: [
        {
          id: 'product-test',
          name: 'Test Product',
          description: 'A simple test product at the minimum price Stripe accepts.',
          imageUrl: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800',
          price: 0.50,
          discountPrice: 0,
          featured: true,
          stripePriceId: 'price_1RF1uvG6O6YX1dWlDsd6I7XU'
        }
      ]},
      { key: 'shopCTA', label: 'Call to Action Text', type: 'text', defaultValue: 'Browse All Products' },
      { key: 'customPackageTitle', label: 'Custom Package Title', type: 'text', defaultValue: 'Custom Software Packages' },
      { key: 'customPackageDescription', label: 'Custom Package Description', type: 'textarea', defaultValue: 'Need a tailored solution? We create custom software packages designed specifically for your business needs and challenges.' },
      { key: 'customPackageFeature1', label: 'Feature 1', type: 'text', defaultValue: 'Custom feature development' },
      { key: 'customPackageFeature2', label: 'Feature 2', type: 'text', defaultValue: 'Integration with existing systems' },
      { key: 'customPackageFeature3', label: 'Feature 3', type: 'text', defaultValue: 'Ongoing support and maintenance' },
      { key: 'customPackageButtonText', label: 'Button Text', type: 'text', defaultValue: 'Request Custom Package' },
    ]
  },
  donate: {
    title: 'Donation Page',
    description: 'Configure your donation page settings',
    fields: [
      // Donation Page Content
      { key: 'donateTitle', label: 'Donation Page Title', type: 'text', defaultValue: 'Support My Work' },
      { key: 'donateDescription', label: 'Donation Page Description', type: 'textarea', defaultValue: 'Your support helps me continue creating quality software and providing valuable resources to the community.' },
      { key: 'donateFooterText', label: 'Donation Page Footer Text', type: 'textarea', defaultValue: 'Your donation directly supports the development of quality open-source software. Thank you for your generosity!' },
      { key: 'donateWhyTitle', label: 'Support Reasons Section Title', type: 'text', defaultValue: 'Why Your Support Matters' },
      
      // Navigation Link Controls
      { key: 'showDonateNavLink', label: 'Show Donate Link in Top Navigation', type: 'switch', defaultValue: true },
      { key: 'donateNavLinkText', label: 'Navigation Link Text', type: 'text', defaultValue: 'Support' },
      
      // Footer Bottom Links
      { key: 'footerDonateLinks', label: 'Footer Bottom Donation Links', type: 'footerDonateLinks', defaultValue: [
        { id: 'donate-link-1', label: 'Donate', href: '/donate' }
      ]},
      
      // Quick Links Donation Links
      { key: 'quickLinksDonateLinks', label: 'Quick Links Donation Links', type: 'quickLinksDonateLinks', defaultValue: [
        { id: 'donate-quick-1', label: 'Support My Work', href: '/donate' }
      ]},
    ]
  },
  contactSection: {
    title: 'Contact Section',
    description: 'Contact form and information settings',
    fields: [
      { key: 'contactTitle', label: 'Contact Section Title', type: 'text', defaultValue: 'Get In Touch' },
      { key: 'contactDescription', label: 'Contact Introduction', type: 'textarea', defaultValue: "I'm always interested in hearing about new projects and opportunities. Feel free to reach out using the form below." },
      { key: 'contactEmail', label: 'Email Address', type: 'text', defaultValue: 'contact@grantedby.fluffy' },
      { key: 'contactPhone', label: 'Phone Number', type: 'text', defaultValue: '+1 (555) 123-4567' },
      { key: 'contactAddress', label: 'Business Address', type: 'textarea', defaultValue: '123 Code Street\nDeveloper City, DC 10101' },
      { key: 'formNameLabel', label: 'Name Field Label', type: 'text', defaultValue: 'Your Name' },
      { key: 'formEmailLabel', label: 'Email Field Label', type: 'text', defaultValue: 'Your Email' },
      { key: 'formSubjectLabel', label: 'Subject Field Label', type: 'text', defaultValue: 'Subject' },
      { key: 'formMessageLabel', label: 'Message Field Label', type: 'text', defaultValue: 'Message' },
      { key: 'formSubmitText', label: 'Submit Button Text', type: 'text', defaultValue: 'Send Message' },
    ]
  },
  footer: {
    title: 'Footer',
    description: 'Footer content and sections customization',
    fields: [
      { key: 'footerText', label: 'Footer Description', type: 'textarea', defaultValue: 'Premium software solutions crafted with precision and care by an independent developer passionate about creating exceptional user experiences.' },
      { key: 'copyrightText', label: 'Copyright Text', type: 'text', defaultValue: 'All rights reserved.' },
      
      // Quick Links Column 
      { key: 'showQuickLinks', label: 'Show Quick Links Section', type: 'switch', defaultValue: true },
      { key: 'quickLinksTitle', label: 'Quick Links Title', type: 'text', defaultValue: 'Quick Links' },
      { key: 'footerQuickLinks', label: 'Quick Links', type: 'footerQuickLinks', defaultValue: [
        { id: 'quicklink-1', label: 'About', href: '#about' },
        { id: 'quicklink-2', label: 'Services', href: '#services' },
        { id: 'quicklink-3', label: 'Portfolio', href: '#portfolio' },
        { id: 'quicklink-4', label: 'Shop', href: '#shop' },
        { id: 'quicklink-5', label: 'Contact', href: '#contact' }
      ]},
      
      // Services Column
      { key: 'showServicesLinks', label: 'Show Services Section', type: 'switch', defaultValue: true },
      { key: 'servicesLinksTitle', label: 'Services Links Title', type: 'text', defaultValue: 'Services' },
      { key: 'footerServiceLinks', label: 'Services Links', type: 'footerServiceLinks', defaultValue: [
        { id: 'servicelink-1', label: 'Custom Software Development', href: '#services' },
        { id: 'servicelink-2', label: 'API Development & Integration', href: '#services' },
        { id: 'servicelink-3', label: 'UI/UX Design', href: '#services' },
        { id: 'servicelink-4', label: 'Software Consulting', href: '#services' },
        { id: 'servicelink-5', label: 'Maintenance & Support', href: '#services' }
      ]},
      
      // Newsletter Section
      { key: 'showNewsletter', label: 'Show Newsletter Section', type: 'switch', defaultValue: true },
      { key: 'newsLetterTitle', label: 'Newsletter Title', type: 'text', defaultValue: 'Newsletter' },
      { key: 'newsLetterText', label: 'Newsletter Description', type: 'textarea', defaultValue: 'Subscribe to receive updates, access to exclusive deals, and more.' },
      { key: 'newsLetterDisclaimer', label: 'Newsletter Disclaimer', type: 'textarea', defaultValue: 'By subscribing, you agree to our Privacy Policy and consent to receive updates from our company.' },
      { key: 'newsLetterPlaceholder', label: 'Newsletter Input Placeholder', type: 'text', defaultValue: 'Your email address' },
    ]
  },
  social: {
    title: 'Social Media',
    description: 'Your social media profiles',
    fields: [
      { key: 'twitterUrl', label: 'Twitter URL', type: 'text', defaultValue: 'https://twitter.com/grantedby.fluffy' },
      { key: 'githubUrl', label: 'GitHub URL', type: 'text', defaultValue: 'https://github.com/grantedby.fluffy' },
      { key: 'linkedinUrl', label: 'LinkedIn URL', type: 'text', defaultValue: 'https://linkedin.com/in/grantedby.fluffy' },
      { key: 'instagramUrl', label: 'Instagram URL', type: 'text', defaultValue: '' },
      { key: 'facebookUrl', label: 'Facebook URL', type: 'text', defaultValue: '' },
      { key: 'youtubeUrl', label: 'YouTube URL', type: 'text', defaultValue: '' },
    ]
  },
};

// Main component
export default function AdminSettings() {
  const [activeTab, setActiveTab] = useState("general");
  const [settings, setSettings] = useState<Record<string, any>>({});
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  
  // Check if user is authenticated through API
  const { data: user, isLoading: isUserLoading } = useQuery({
    queryKey: ['/api/user'],
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', '/api/user');
        if (res.status === 401) return null;
        return await res.json();
      } catch (error) {
        console.error('Error checking user authentication:', error);
        return null;
      }
    }
  });
  
  // Fetch all settings
  const { data, isLoading, refetch } = useQuery({
    queryKey: ['/api/settings'],
    queryFn: async () => {
      try {
        // Add timestamp to prevent caching
        const res = await apiRequest('GET', `/api/settings?t=${Date.now()}`);
        if (!res.ok) {
          throw new Error('Failed to fetch settings');
        }
        const data = await res.json();
        return data;
      } catch (error) {
        console.error('Error fetching settings:', error);
        return {};
      }
    },
    enabled: !!user, // Only fetch settings when user is available
    staleTime: 0, // Consider data immediately stale
    refetchOnMount: true, // Always refetch on component mount
    refetchOnWindowFocus: true // Refetch when window is focused
  });
  
  // Update settings mutation
  const { mutate, isPending } = useMutation({
    mutationFn: async (updatedSettings: Record<string, any>) => {
      const res = await apiRequest('POST', '/api/admin/settings', updatedSettings);
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || 'Failed to update settings');
      }
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: 'Settings Updated',
        description: 'Your website settings have been updated successfully.',
      });
      
      // Force refetch the settings with fresh data
      queryClient.invalidateQueries({ queryKey: ['/api/settings'] });
      refetch();
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: `Failed to update settings: ${error.message}`,
        variant: 'destructive',
      });
    }
  });
  
  // Initialize settings with defaults or fetched values
  useEffect(() => {
    if (data) {
      const mergedSettings: Record<string, any> = {};
      
      // First, set all defaults
      Object.values(WEBSITE_SETTINGS).forEach(section => {
        section.fields.forEach(field => {
          mergedSettings[field.key] = field.defaultValue;
        });
      });
      
      // Then override with actual values from database
      Object.keys(data).forEach(key => {
        mergedSettings[key] = data[key];
      });
      
      setSettings(mergedSettings);
    }
  }, [data]);
  
  // Handle input changes
  // Helper function to ensure boolean values for switches
  const ensureBoolean = (value: any): boolean => {
    if (typeof value === 'boolean') return value;
    if (value === 'true') return true;
    if (value === 'false') return false;
    return !!value;
  };

  const handleChange = (key: string, value: any) => {
    setSettings(prev => ({
      ...prev,
      [key]: value
    }));
  };
  
  // Handle settings save
  const handleSave = () => {
    mutate(settings);
  };
  
  // Render loading state
  if (isLoading || isUserLoading) {
    return (
      <div className="w-full h-[80vh] flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }
  
  // Redirect to login if not authenticated or not admin
  if (!user || !user.isAdmin) {
    return <Redirect to="/admin-login" />;
  }
  
  return (
    <div className="container py-10 max-w-5xl">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold">Website Settings</h1>
          <p className="text-muted-foreground mt-1">Customize your website content and appearance</p>
        </div>
        <Button 
          onClick={handleSave} 
          disabled={isPending}
          className="flex gap-2 items-center"
        >
          {isPending && <Loader2 className="h-4 w-4 animate-spin" />}
          <Save className="h-4 w-4 mr-1" />
          Save Changes
        </Button>
      </div>
      
      <Tabs defaultValue="general" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="mb-6 grid grid-cols-3 md:grid-cols-6 gap-2">
          {Object.keys(WEBSITE_SETTINGS).map(key => (
            <TabsTrigger key={key} value={key} className="capitalize">
              {key}
            </TabsTrigger>
          ))}
        </TabsList>
        
        {Object.entries(WEBSITE_SETTINGS).map(([sectionKey, section]) => (
          <TabsContent key={sectionKey} value={sectionKey} className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle>{section.title}</CardTitle>
                <CardDescription>{section.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-6">
                  {section.fields.map(field => (
                    <div key={field.key} className="grid gap-2">
                      <Label htmlFor={field.key}>{field.label}</Label>
                      {field.type === 'textarea' ? (
                        <Textarea
                          id={field.key}
                          value={settings[field.key] || ''}
                          onChange={e => handleChange(field.key, e.target.value)}
                          rows={4}
                        />
                      ) : field.type === 'color' ? (
                        <div className="flex gap-2 items-center">
                          <Input
                            type="color"
                            id={field.key}
                            value={settings[field.key] || field.defaultValue}
                            onChange={e => handleChange(field.key, e.target.value)}
                            className="w-16 h-10 p-1"
                          />
                          <Input
                            type="text"
                            value={settings[field.key] || field.defaultValue}
                            onChange={e => handleChange(field.key, e.target.value)}
                            className="flex-1"
                          />
                        </div>
                      ) : field.type === 'dynamicServices' ? (
                        <DynamicServicesManager
                          services={settings[field.key] || field.defaultValue}
                          onChange={(services) => handleChange(field.key, services)}
                        />
                      ) : field.type === 'dynamicProducts' ? (
                        <DynamicProductsManager
                          products={settings[field.key] || field.defaultValue}
                          onChange={(products) => handleChange(field.key, products)}
                        />
                      ) : field.type === 'footerQuickLinks' ? (
                        <FooterQuickLinksManager
                          links={settings[field.key] || field.defaultValue}
                          onChange={(links) => handleChange(field.key, links)}
                        />
                      ) : field.type === 'footerServiceLinks' ? (
                        <FooterServicesLinksManager
                          links={settings[field.key] || field.defaultValue}
                          onChange={(links) => handleChange(field.key, links)}
                        />
                      ) : field.type === 'footerDonateLinks' ? (
                        <FooterLinksManager
                          links={settings[field.key] || field.defaultValue}
                          onChange={(links) => handleChange(field.key, links)}
                          title="Footer Donation Links"
                          description="Manage donation links displayed at the bottom of the footer"
                        />
                      ) : field.type === 'quickLinksDonateLinks' ? (
                        <FooterLinksManager
                          links={settings[field.key] || field.defaultValue}
                          onChange={(links) => handleChange(field.key, links)}
                          title="Quick Links Donation Links"
                          description="Manage donation links displayed in the Quick Links section"
                        />
                      ) : field.type === 'switch' ? (
                        <div className="flex items-center space-x-2">
                          <Switch
                            id={field.key}
                            checked={settings[field.key] === undefined ? ensureBoolean(field.defaultValue) : ensureBoolean(settings[field.key])}
                            onCheckedChange={(checked) => handleChange(field.key, checked)}
                          />
                          <span className="text-sm text-muted-foreground">
                            {settings[field.key] === undefined 
                              ? (ensureBoolean(field.defaultValue) ? 'Enabled' : 'Disabled') 
                              : (ensureBoolean(settings[field.key]) ? 'Enabled' : 'Disabled')}
                          </span>
                        </div>
                      ) : (
                        <Input
                          type={field.type}
                          id={field.key}
                          value={settings[field.key] || ''}
                          onChange={e => handleChange(field.key, e.target.value)}
                        />
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
              <CardFooter className="flex justify-end">
                <Button onClick={handleSave} disabled={isPending}>
                  {isPending && <Loader2 className="h-4 w-4 animate-spin mr-2" />}
                  Save {section.title}
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}