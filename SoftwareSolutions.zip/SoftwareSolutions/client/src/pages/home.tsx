import React from "react";
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";
import HeroSection from "@/sections/hero-section";
import AboutSection from "@/sections/about-section";
import ServicesSection from "@/sections/services-section";
import ShopSection from "@/sections/shop-section";
import ContactSection from "@/sections/contact-section";
import { Helmet } from "react-helmet-async";

const Home: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>GrantedByFluffy - Premium Software Development</title>
        <meta name="description" content="Premium software solutions crafted with precision and care by an independent developer passionate about creating exceptional user experiences." />
      </Helmet>
      
      <Navbar />
      
      <main>
        <HeroSection />
        <AboutSection />
        <ServicesSection />
        <ShopSection />
        <ContactSection />
      </main>
      
      <Footer />
    </>
  );
};

export default Home;
