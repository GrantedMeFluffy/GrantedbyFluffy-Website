import React, { useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import { useSettings } from '@/hooks/use-settings';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Heart, Loader2, Coffee, ArrowRight } from 'lucide-react';
import { createDonation } from '@/lib/stripe';

// Define donation tiers
const DONATION_TIERS = [
  { value: 5, label: 'Buy me a coffee', icon: Coffee },
  { value: 10, label: 'Small Support', icon: Heart },
  { value: 25, label: 'Medium Support', icon: Heart },
  { value: 50, label: 'Major Support', icon: Heart },
  { value: 100, label: 'Premium Support', icon: Heart },
];

// Define donation form schema
const donationSchema = z.object({
  amount: z.preprocess(
    (val) => (val === '' ? undefined : Number(val)),
    z.number().min(1, 'Amount must be at least $1').max(10000, 'Amount cannot exceed $10,000')
  ),
  name: z.string().optional(),
  email: z.string().email('Please enter a valid email address').optional(),
  message: z.string().max(500, 'Message cannot exceed 500 characters').optional(),
  isAnonymous: z.boolean().default(false),
  isRecurring: z.boolean().default(false),
});

type DonationFormValues = z.infer<typeof donationSchema>;

export default function DonatePage() {
  const { toast } = useToast();
  const { settings } = useSettings();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [customAmount, setCustomAmount] = useState(false);
  
  // Initialize form with default values
  const form = useForm<DonationFormValues>({
    resolver: zodResolver(donationSchema),
    defaultValues: {
      amount: 5,
      name: '',
      email: '',
      message: '',
      isAnonymous: false,
      isRecurring: false,
    },
  });
  
  // Handle form submission
  const onSubmit = async (data: DonationFormValues) => {
    try {
      setIsSubmitting(true);
      
      const donationResponse = await createDonation(
        data.amount, 
        data.isRecurring,
        {
          name: data.isAnonymous ? 'Anonymous' : data.name,
          email: data.email,
          message: data.message
        }
      );
      
      if (donationResponse.url) {
        window.location.href = donationResponse.url;
      } else {
        throw new Error('Failed to create donation checkout session');
      }
    } catch (error) {
      console.error('Donation error:', error);
      toast({
        title: 'Donation Failed',
        description: error instanceof Error ? error.message : 'Something went wrong. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  // Handle tier selection
  const handleTierSelect = (amount: number) => {
    setCustomAmount(false);
    form.setValue('amount', amount);
  };
  
  // Handle custom amount toggle
  const toggleCustomAmount = () => {
    setCustomAmount(!customAmount);
    if (!customAmount) {
      form.setValue('amount', undefined as any);
    } else {
      form.setValue('amount', 5);
    }
  };
  
  return (
    <div className="container mx-auto py-16 px-4">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">{settings.donateTitle || 'Support My Work'}</h1>
          <p className="text-xl text-muted-foreground mb-8">
            {settings.donateDescription || 'Your support helps me continue creating quality software and providing valuable resources to the community.'}
          </p>
        </div>
        
        <Card className="mb-10">
          <CardHeader>
            <CardTitle>Choose a Donation Amount</CardTitle>
            <CardDescription>Select a predefined amount or enter a custom value</CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                {/* Donation tiers */}
                <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
                  {DONATION_TIERS.map((tier) => {
                    const Icon = tier.icon;
                    return (
                      <Button
                        key={tier.value}
                        type="button"
                        variant={form.watch('amount') === tier.value && !customAmount ? 'default' : 'outline'}
                        className="flex flex-col items-center py-6 h-auto"
                        onClick={() => handleTierSelect(tier.value)}
                      >
                        <Icon className="h-6 w-6 mb-2" />
                        <span className="font-bold">${tier.value}</span>
                        <span className="text-xs mt-1">{tier.label}</span>
                      </Button>
                    );
                  })}
                </div>
                
                {/* Custom amount toggle */}
                <div className="flex items-center space-x-2 mb-4">
                  <Switch
                    id="custom-amount"
                    checked={customAmount}
                    onCheckedChange={toggleCustomAmount}
                  />
                  <Label htmlFor="custom-amount">Enter a custom amount</Label>
                </div>
                
                {/* Custom amount input */}
                {customAmount && (
                  <FormField
                    control={form.control}
                    name="amount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Custom Amount ($)</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <span className="absolute left-3 top-1/2 -translate-y-1/2">$</span>
                            <Input
                              {...field}
                              type="number"
                              placeholder="Enter amount"
                              className="pl-8"
                              value={field.value || ''}
                              onChange={(e) => field.onChange(e.target.value === '' ? '' : Number(e.target.value))}
                            />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}
                
                {/* Recurring donation option */}
                <FormField
                  control={form.control}
                  name="isRecurring"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center space-x-3 space-y-0 rounded-md border p-4">
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>Make this a monthly donation</FormLabel>
                        <FormDescription>
                          Support my work with a recurring monthly donation
                        </FormDescription>
                      </div>
                    </FormItem>
                  )}
                />
                
                {/* Personal details */}
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Your Information (Optional)</h3>
                  
                  <FormField
                    control={form.control}
                    name="isAnonymous"
                    render={({ field }) => (
                      <FormItem className="flex items-center space-x-2">
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <FormLabel>Donate anonymously</FormLabel>
                      </FormItem>
                    )}
                  />
                  
                  {!form.watch('isAnonymous') && (
                    <>
                      <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Name</FormLabel>
                            <FormControl>
                              <Input {...field} placeholder="Your name (optional)" />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email</FormLabel>
                            <FormControl>
                              <Input {...field} type="email" placeholder="Your email (optional)" />
                            </FormControl>
                            <FormDescription>
                              I'll use this to thank you for your donation
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </>
                  )}
                  
                  <FormField
                    control={form.control}
                    name="message"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Message (Optional)</FormLabel>
                        <FormControl>
                          <Textarea
                            {...field}
                            placeholder="Add a message with your donation"
                            className="resize-none"
                            rows={3}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <Button 
                  type="submit" 
                  className="w-full py-6 text-lg"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  ) : (
                    <Heart className="mr-2 h-5 w-5" />
                  )}
                  {form.watch('isRecurring') 
                    ? `Donate $${form.watch('amount') || 0} Monthly` 
                    : `Donate $${form.watch('amount') || 0}`}
                </Button>
              </form>
            </Form>
          </CardContent>
          <CardFooter className="justify-center border-t pt-6">
            <p className="text-sm text-muted-foreground text-center max-w-md">
              {settings.donateFooterText || 
                "Your donation directly supports the development of quality open-source software. Thank you for your generosity!"}
            </p>
          </CardFooter>
        </Card>
        
        {/* Why donate section */}
        <div className="mt-16">
          <h2 className="text-2xl font-bold mb-6">{settings.donateWhyTitle || 'Why Your Support Matters'}</h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            <Card>
              <CardHeader>
                <CardTitle>Enable New Features</CardTitle>
              </CardHeader>
              <CardContent>
                <p>Your donations help fund the development of new features and products that benefit the entire community.</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Improve Quality</CardTitle>
              </CardHeader>
              <CardContent>
                <p>Support allows for more time to be dedicated to improving code quality, performance, and reliability.</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Sustain Development</CardTitle>
              </CardHeader>
              <CardContent>
                <p>Ongoing support ensures that this project can be maintained and improved over the long term.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}