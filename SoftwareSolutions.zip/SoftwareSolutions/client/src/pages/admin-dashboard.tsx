import React, { useState, useEffect } from 'react';
import { useLocation, Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { Helmet } from 'react-helmet-async';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Loader2, Plus, Pencil, Trash2, LogOut } from 'lucide-react';

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  discountPrice: number | null;
  imageUrl: string | null;
  tags: string[] | null;
  stripePriceId: string | null;
  featured: boolean | null;
}

const AdminDashboard: React.FC = () => {
  const { toast } = useToast();
  const [_, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const [user, setUser] = useState<any>(null);
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  
  // Product form state
  const [productForm, setProductForm] = useState({
    id: '',
    name: '',
    description: '',
    price: '',
    discountPrice: '',
    tags: '',
    featured: false,
    imageFile: null as File | null,
    imagePreview: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  
  // Fetch current user
  useEffect(() => {
    const checkAuth = async () => {
      try {
        const response = await fetch('/api/user');
        if (!response.ok) {
          throw new Error('Not authenticated');
        }
        
        const userData = await response.json();
        
        if (!userData.isAdmin) {
          throw new Error('Admin privileges required');
        }
        
        setUser(userData);
      } catch (error) {
        toast({
          title: 'Authentication Error',
          description: 'Please log in with admin credentials',
          variant: 'destructive',
        });
        setLocation('/admin-login');
      }
    };
    
    checkAuth();
  }, [setLocation, toast]);
  
  // Fetch products data
  const { data: products, isLoading, error } = useQuery({
    queryKey: ['/api/admin/products'],
    queryFn: async () => {
      const response = await fetch('/api/admin/products');
      if (!response.ok) {
        throw new Error('Failed to fetch products');
      }
      return response.json();
    },
    enabled: !!user,
  });
  
  // Handle logout
  const handleLogout = async () => {
    setIsLoggingOut(true);
    
    try {
      const response = await fetch('/api/logout', {
        method: 'POST',
      });
      
      if (!response.ok) {
        throw new Error('Logout failed');
      }
      
      toast({
        title: 'Logged Out',
        description: 'You have been logged out successfully',
      });
      
      setLocation('/admin-login');
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to log out',
        variant: 'destructive',
      });
    } finally {
      setIsLoggingOut(false);
    }
  };
  
  // Reset product form
  const resetProductForm = () => {
    setProductForm({
      id: '',
      name: '',
      description: '',
      price: '',
      discountPrice: '',
      tags: '',
      featured: false,
      imageFile: null,
      imagePreview: '',
    });
    setIsEditMode(false);
  };
  
  // Open product form for editing
  const handleEditProduct = (product: Product) => {
    setProductForm({
      id: product.id,
      name: product.name,
      description: product.description,
      price: (product.price / 100).toFixed(2), // Convert cents to dollars for display
      discountPrice: product.discountPrice ? (product.discountPrice / 100).toFixed(2) : '',
      tags: product.tags ? product.tags.join(', ') : '',
      featured: !!product.featured,
      imageFile: null,
      imagePreview: product.imageUrl || '',
    });
    setIsEditMode(true);
    setIsDialogOpen(true);
  };
  
  // Handle file selection
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProductForm(prev => ({
          ...prev,
          imageFile: file,
          imagePreview: reader.result as string,
        }));
      };
      reader.readAsDataURL(file);
    }
  };
  
  // Submit product form
  const handleSubmitProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      // Create form data for file upload
      const formData = new FormData();
      
      // Add product data as JSON
      const productData = {
        name: productForm.name,
        description: productForm.description,
        price: parseFloat(productForm.price),
        discountPrice: productForm.discountPrice ? parseFloat(productForm.discountPrice) : null,
        tags: productForm.tags,
        featured: productForm.featured,
      };
      
      formData.append('productData', JSON.stringify(productData));
      
      // Add image file if present
      if (productForm.imageFile) {
        formData.append('image', productForm.imageFile);
      }
      
      let response;
      
      if (isEditMode) {
        // Update existing product
        response = await fetch(`/api/admin/products/${productForm.id}`, {
          method: 'PUT',
          body: formData,
        });
      } else {
        // Create new product
        response = await fetch('/api/admin/products', {
          method: 'POST',
          body: formData,
        });
      }
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to save product');
      }
      
      // Refresh products list
      queryClient.invalidateQueries({ queryKey: ['/api/admin/products'] });
      
      toast({
        title: isEditMode ? 'Product Updated' : 'Product Created',
        description: `Successfully ${isEditMode ? 'updated' : 'created'} product`,
      });
      
      // Close dialog and reset form
      setIsDialogOpen(false);
      resetProductForm();
    } catch (error) {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'An error occurred',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  // Delete product
  const confirmDelete = async () => {
    if (!deleteId) return;
    
    setIsDeleting(true);
    
    try {
      const response = await fetch(`/api/admin/products/${deleteId}`, {
        method: 'DELETE',
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to delete product');
      }
      
      // Refresh products list
      queryClient.invalidateQueries({ queryKey: ['/api/admin/products'] });
      
      toast({
        title: 'Product Deleted',
        description: 'Product has been removed successfully',
      });
      
      setDeleteId(null);
    } catch (error) {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'An error occurred',
        variant: 'destructive',
      });
    } finally {
      setIsDeleting(false);
    }
  };
  
  // Show loading state
  if (isLoading || !user) {
    return (
      <div className="h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  // Handle error
  if (error) {
    return (
      <div className="h-screen flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Error</CardTitle>
            <CardDescription>Failed to load admin dashboard</CardDescription>
          </CardHeader>
          <CardContent>
            {error instanceof Error ? error.message : 'An unknown error occurred'}
          </CardContent>
          <CardFooter>
            <Button variant="outline" onClick={() => setLocation('/admin-login')}>
              Return to Login
            </Button>
          </CardFooter>
        </Card>
      </div>
    );
  }
  
  return (
    <>
      <Helmet>
        <title>Admin Dashboard | GrantedByFluffy</title>
      </Helmet>
      
      <div className="min-h-screen bg-background">
        {/* Header */}
        <header className="bg-card border-b border-border shadow-sm py-4">
          <div className="container mx-auto px-4 flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <h1 className="text-xl font-bold">Admin Dashboard</h1>
              <span className="text-sm bg-primary/10 text-primary py-1 px-2 rounded-full">
                {user.username}
              </span>
            </div>
            
            <div className="flex items-center space-x-2">
              <Button variant="outline" asChild>
                <Link href="/">View Website</Link>
              </Button>
              
              <Button 
                variant="destructive" 
                size="sm" 
                onClick={handleLogout}
                disabled={isLoggingOut}
              >
                {isLoggingOut ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <>
                    <LogOut className="mr-2 h-4 w-4" />
                    Logout
                  </>
                )}
              </Button>
            </div>
          </div>
        </header>
        
        {/* Main content */}
        <main className="container mx-auto px-4 py-8">
          <div className="grid gap-8 grid-cols-1 md:grid-cols-2 mb-8">
            <Card>
              <CardHeader>
                <CardTitle>Products Management</CardTitle>
                <CardDescription>Manage your software products in the store</CardDescription>
              </CardHeader>
              <CardContent>
                <p>Add, edit, or remove products from your online store. Set prices, descriptions, and upload product images.</p>
              </CardContent>
              <CardFooter>
                <Button className="w-full" onClick={() => setLocation('/admin-dashboard')}>
                  Manage Products
                </Button>
              </CardFooter>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Page Management</CardTitle>
                <CardDescription>Manage website pages and content</CardDescription>
              </CardHeader>
              <CardContent>
                <p>Create and edit website pages with full revision history. Make changes with the ability to undo and restore previous versions.</p>
              </CardContent>
              <CardFooter>
                <Button className="w-full" onClick={() => setLocation('/admin-pages')}>
                  Manage Pages
                </Button>
              </CardFooter>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Website Settings</CardTitle>
                <CardDescription>Configure website-wide content and appearance</CardDescription>
              </CardHeader>
              <CardContent>
                <p>Update your website's general information, appearance settings, contact details, and social media links from a single dashboard.</p>
              </CardContent>
              <CardFooter>
                <Button className="w-full" onClick={() => setLocation('/admin-settings')}>
                  Manage Settings
                </Button>
              </CardFooter>
            </Card>
          </div>
        
          <div className="mb-6">
            <h2 className="text-2xl font-bold mb-4">Products Management</h2>
            
            <div className="flex justify-between items-center mb-4">
              <p className="text-muted-foreground">
                Manage your store products and their details
              </p>
              
              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button 
                    onClick={() => {
                      resetProductForm();
                      setIsEditMode(false);
                    }}
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    Add New Product
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>
                      {isEditMode ? 'Edit Product' : 'Create New Product'}
                    </DialogTitle>
                    <DialogDescription>
                      {isEditMode 
                        ? 'Update the details of an existing product' 
                        : 'Fill in the details to add a new product to your store'}
                    </DialogDescription>
                  </DialogHeader>
                  
                  <form onSubmit={handleSubmitProduct} className="space-y-6 mt-4">
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="name">Product Name</Label>
                        <Input
                          id="name"
                          value={productForm.name}
                          onChange={e => setProductForm({ ...productForm, name: e.target.value })}
                          placeholder="e.g. DevTracker Pro"
                          required
                        />
                      </div>
                      
                      <div>
                        <Label htmlFor="description">Description</Label>
                        <Textarea
                          id="description"
                          value={productForm.description}
                          onChange={e => setProductForm({ ...productForm, description: e.target.value })}
                          placeholder="Describe your product"
                          required
                          rows={4}
                        />
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="price">Price ($)</Label>
                          <Input
                            id="price"
                            type="number"
                            step="0.01"
                            min="0"
                            value={productForm.price}
                            onChange={e => setProductForm({ ...productForm, price: e.target.value })}
                            placeholder="49.99"
                            required
                          />
                        </div>
                        
                        <div>
                          <Label htmlFor="discountPrice">Discount Price ($)</Label>
                          <Input
                            id="discountPrice"
                            type="number"
                            step="0.01"
                            min="0"
                            value={productForm.discountPrice}
                            onChange={e => setProductForm({ ...productForm, discountPrice: e.target.value })}
                            placeholder="39.99"
                          />
                        </div>
                      </div>
                      
                      <div>
                        <Label htmlFor="tags">Tags (comma-separated)</Label>
                        <Input
                          id="tags"
                          value={productForm.tags}
                          onChange={e => setProductForm({ ...productForm, tags: e.target.value })}
                          placeholder="e.g. Development, Tool, Software"
                        />
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="featured"
                          checked={productForm.featured}
                          onCheckedChange={(checked) => 
                            setProductForm({ ...productForm, featured: checked as boolean })
                          }
                        />
                        <Label htmlFor="featured">Featured Product</Label>
                      </div>
                      
                      <div>
                        <Label htmlFor="image">Product Image</Label>
                        <Input
                          id="image"
                          type="file"
                          accept="image/*"
                          onChange={handleFileChange}
                          className="mt-1"
                        />
                        
                        {productForm.imagePreview && (
                          <div className="mt-4 border rounded-md p-2">
                            <p className="text-sm text-muted-foreground mb-2">Image Preview:</p>
                            <img 
                              src={productForm.imagePreview} 
                              alt="Product preview" 
                              className="w-full max-h-48 object-contain rounded-md"
                            />
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <DialogFooter>
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={() => setIsDialogOpen(false)}
                      >
                        Cancel
                      </Button>
                      <Button 
                        type="submit"
                        disabled={isSubmitting}
                      >
                        {isSubmitting ? (
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        ) : null}
                        {isEditMode ? 'Update Product' : 'Create Product'}
                      </Button>
                    </DialogFooter>
                  </form>
                </DialogContent>
              </Dialog>
            </div>
            
            {/* Products table */}
            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Image</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Price</TableHead>
                      <TableHead>Featured</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {products && products.length > 0 ? (
                      products.map((product: Product) => (
                        <TableRow key={product.id}>
                          <TableCell>
                            {product.imageUrl ? (
                              <img 
                                src={product.imageUrl} 
                                alt={product.name}
                                className="w-16 h-16 object-cover rounded-md"
                              />
                            ) : (
                              <div className="w-16 h-16 bg-muted flex items-center justify-center rounded-md">
                                No image
                              </div>
                            )}
                          </TableCell>
                          <TableCell>
                            <div className="font-medium">{product.name}</div>
                            <div className="text-sm text-muted-foreground truncate max-w-xs">
                              {product.description}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="font-medium">
                              ${(product.price / 100).toFixed(2)}
                            </div>
                            {product.discountPrice && (
                              <div className="text-sm text-muted-foreground line-through">
                                ${(product.discountPrice / 100).toFixed(2)}
                              </div>
                            )}
                          </TableCell>
                          <TableCell>
                            {product.featured ? (
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                Featured
                              </span>
                            ) : (
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                                Regular
                              </span>
                            )}
                          </TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Button 
                                variant="outline" 
                                size="sm"
                                onClick={() => handleEditProduct(product)}
                              >
                                <Pencil className="h-4 w-4" />
                                <span className="sr-only">Edit</span>
                              </Button>
                              
                              <Dialog open={deleteId === product.id} onOpenChange={(open) => {
                                if (!open) setDeleteId(null);
                              }}>
                                <DialogTrigger asChild>
                                  <Button 
                                    variant="destructive" 
                                    size="sm"
                                    onClick={() => setDeleteId(product.id)}
                                  >
                                    <Trash2 className="h-4 w-4" />
                                    <span className="sr-only">Delete</span>
                                  </Button>
                                </DialogTrigger>
                                <DialogContent>
                                  <DialogHeader>
                                    <DialogTitle>Confirm Deletion</DialogTitle>
                                    <DialogDescription>
                                      Are you sure you want to delete "{product.name}"? This action cannot be undone.
                                    </DialogDescription>
                                  </DialogHeader>
                                  <DialogFooter className="flex space-x-2 justify-end">
                                    <Button 
                                      variant="outline" 
                                      onClick={() => setDeleteId(null)}
                                    >
                                      Cancel
                                    </Button>
                                    <Button 
                                      variant="destructive" 
                                      onClick={confirmDelete}
                                      disabled={isDeleting}
                                    >
                                      {isDeleting ? (
                                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                      ) : null}
                                      Delete
                                    </Button>
                                  </DialogFooter>
                                </DialogContent>
                              </Dialog>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-6">
                          <div className="flex flex-col items-center justify-center space-y-2">
                            <p>No products found</p>
                            <Button variant="outline" size="sm" onClick={() => setIsDialogOpen(true)}>
                              <Plus className="mr-2 h-4 w-4" />
                              Add Your First Product
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </>
  );
};

export default AdminDashboard;