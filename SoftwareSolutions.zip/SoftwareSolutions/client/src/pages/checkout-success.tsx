import React from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Helmet } from 'react-helmet-async';
import Logo from '@/components/logo';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { CheckCircle } from 'lucide-react';

const CheckoutSuccess: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Payment Successful | GrantedByFluffy</title>
      </Helmet>
      
      <div className="min-h-screen flex flex-col">
        <header className="border-b py-4">
          <div className="container mx-auto px-4">
            <Link href="/">
              <a className="flex items-center">
                <Logo showText={true} />
              </a>
            </Link>
          </div>
        </header>
        
        <main className="flex-1 py-12">
          <div className="container max-w-2xl mx-auto px-4">
            <Card className="shadow-lg">
              <CardHeader className="text-center pb-2">
                <CardTitle className="text-2xl font-bold">Payment Successful</CardTitle>
              </CardHeader>
              
              <CardContent className="flex flex-col items-center text-center py-8">
                <CheckCircle className="w-20 h-20 text-green-500 mb-6" />
                
                <h2 className="text-xl font-bold mb-4">Thank you for your purchase!</h2>
                
                <p className="text-muted-foreground mb-6">
                  Your order has been successfully processed. You should receive an email confirmation shortly.
                </p>
                
                <div className="bg-muted p-6 rounded-lg w-full mb-6">
                  <h3 className="font-semibold mb-2">What's Next?</h3>
                  <ul className="text-left space-y-2">
                    <li className="flex items-start">
                      <span className="text-primary mr-2">•</span>
                      <span>Check your email for order details and download instructions.</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-primary mr-2">•</span>
                      <span>For digital products, download links will be provided in your email.</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-primary mr-2">•</span>
                      <span>If you have any questions or need assistance, please contact support.</span>
                    </li>
                  </ul>
                </div>
              </CardContent>
              
              <CardFooter className="flex justify-center gap-4 pt-2 pb-6">
                <Link href="/">
                  <Button>
                    Return to Homepage
                  </Button>
                </Link>
                <Link href="/#shop">
                  <Button variant="outline">
                    Continue Shopping
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          </div>
        </main>
        
        <footer className="border-t py-4 text-center text-sm text-muted-foreground">
          <div className="container mx-auto px-4">
            &copy; {new Date().getFullYear()} GrantedByFluffy. All rights reserved.
          </div>
        </footer>
      </div>
    </>
  );
};

export default CheckoutSuccess;