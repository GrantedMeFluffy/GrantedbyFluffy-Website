import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useLocation, Link } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { Loader2, Trash2, Edit, Save, Plus, Undo, Eye, EyeOff, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// Types
interface Page {
  id: number;
  title: string;
  slug: string;
  content: string;
  isPublished: boolean;
  metaDescription: string | null;
  createdAt: string;
  updatedAt: string;
  revisions: PageRevision[];
}

interface PageRevision {
  title: string;
  content: string;
  timestamp: string;
}

interface PageFormData {
  id?: number;
  title: string;
  slug: string;
  content: string;
  isPublished: boolean;
  metaDescription: string;
}

export default function AdminPages() {
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // State
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [selectedPage, setSelectedPage] = useState<Page | null>(null);
  const [formData, setFormData] = useState<PageFormData>({
    title: "",
    slug: "",
    content: "",
    isPublished: true,
    metaDescription: "",
  });
  const [isCreating, setIsCreating] = useState<boolean>(false);
  const [isRevisionsOpen, setIsRevisionsOpen] = useState<boolean>(false);
  const [selectedRevisionIndex, setSelectedRevisionIndex] = useState<number | null>(null);
  const [isDeletingPage, setIsDeletingPage] = useState<boolean>(false);
  
  // Queries and Mutations
  const { 
    data: pages, 
    isLoading: isPagesLoading, 
    error: pagesError
  } = useQuery({
    queryKey: ["/api/admin/pages"],
    queryFn: getQueryFn,
  });
  
  const createPageMutation = useMutation({
    mutationFn: async (data: PageFormData) => {
      const res = await apiRequest("POST", "/api/admin/pages", data);
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || "Failed to create page");
      }
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/pages"] });
      setIsCreating(false);
      resetForm();
      toast({
        title: "Success",
        description: "Page created successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const updatePageMutation = useMutation({
    mutationFn: async (data: PageFormData) => {
      const res = await apiRequest("PUT", `/api/admin/pages/${data.id}`, data);
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || "Failed to update page");
      }
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/pages"] });
      setIsEditing(false);
      resetForm();
      toast({
        title: "Success",
        description: "Page updated successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const deletePageMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("DELETE", `/api/admin/pages/${id}`);
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || "Failed to delete page");
      }
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/pages"] });
      setIsDeletingPage(false);
      setSelectedPage(null);
      toast({
        title: "Success",
        description: "Page deleted successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const restoreRevisionMutation = useMutation({
    mutationFn: async ({ pageId, revisionIndex }: { pageId: number; revisionIndex: number }) => {
      const res = await apiRequest("POST", `/api/admin/pages/${pageId}/restore/${revisionIndex}`);
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || "Failed to restore revision");
      }
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/pages"] });
      setIsRevisionsOpen(false);
      setSelectedRevisionIndex(null);
      toast({
        title: "Success",
        description: "Revision restored successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Fetch page data
  async function getQueryFn() {
    const res = await apiRequest("GET", "/api/admin/pages");
    if (!res.ok) {
      if (res.status === 401) {
        setLocation("/admin-login");
        throw new Error("Unauthorized");
      }
      throw new Error("Failed to fetch pages");
    }
    return await res.json();
  }
  
  // Handle form submission
  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    
    if (!formData.title || !formData.slug || !formData.content) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }
    
    if (isCreating) {
      createPageMutation.mutate(formData);
    } else if (isEditing && selectedPage) {
      updatePageMutation.mutate({
        ...formData,
        id: selectedPage.id,
      });
    }
  }
  
  // Reset form
  function resetForm() {
    setFormData({
      title: "",
      slug: "",
      content: "",
      isPublished: true,
      metaDescription: "",
    });
  }
  
  function handleEditPage(page: Page) {
    setSelectedPage(page);
    setFormData({
      title: page.title,
      slug: page.slug,
      content: page.content,
      isPublished: page.isPublished,
      metaDescription: page.metaDescription || "",
    });
    setIsEditing(true);
  }
  
  function handleCreateNew() {
    setSelectedPage(null);
    resetForm();
    setIsCreating(true);
  }
  
  function handleCancel() {
    setIsEditing(false);
    setIsCreating(false);
    resetForm();
  }
  
  function handleDeletePage(page: Page) {
    setSelectedPage(page);
    setIsDeletingPage(true);
  }
  
  function confirmDeletePage() {
    if (selectedPage) {
      deletePageMutation.mutate(selectedPage.id);
    }
  }
  
  function handleViewRevisions(page: Page) {
    setSelectedPage(page);
    setIsRevisionsOpen(true);
  }
  
  function handleRestoreRevision() {
    if (selectedPage && selectedRevisionIndex !== null) {
      restoreRevisionMutation.mutate({
        pageId: selectedPage.id,
        revisionIndex: selectedRevisionIndex,
      });
    }
  }
  
  function handleInputChange(e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  }
  
  // Auto-generate slug from title
  function handleTitleChange(e: React.ChangeEvent<HTMLInputElement>) {
    const title = e.target.value;
    setFormData(prev => ({
      ...prev,
      title,
      slug: prev.slug || title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, ""),
    }));
  }
  
  function handleSwitchChange(checked: boolean) {
    setFormData(prev => ({ ...prev, isPublished: checked }));
  }
  
  if (isPagesLoading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  if (pagesError) {
    return (
      <div className="h-screen flex flex-col items-center justify-center gap-4">
        <AlertTriangle className="h-12 w-12 text-destructive" />
        <h1 className="text-2xl font-bold">Error Loading Pages</h1>
        <p>Failed to load pages. Please try again later.</p>
        <Button onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/admin/pages"] })}>
          Retry
        </Button>
        <Button variant="outline" asChild>
          <Link href="/admin-dashboard">Back to Dashboard</Link>
        </Button>
      </div>
    );
  }
  
  return (
    <div className="container py-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold">Page Management</h1>
          <p className="text-muted-foreground">Create and manage website pages</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" asChild>
            <Link href="/admin-dashboard">Back to Dashboard</Link>
          </Button>
          <Button onClick={handleCreateNew}>
            <Plus className="mr-2 h-4 w-4" /> New Page
          </Button>
        </div>
      </div>
      
      {/* Page List */}
      {!isEditing && !isCreating && (
        <div className="bg-card rounded-lg border shadow-sm">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Title</TableHead>
                <TableHead>Slug</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Updated</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {pages && pages.length > 0 ? (
                pages.map((page: Page) => (
                  <TableRow key={page.id}>
                    <TableCell className="font-medium">{page.title}</TableCell>
                    <TableCell>{page.slug}</TableCell>
                    <TableCell>
                      {page.isPublished ? (
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                          <Eye className="mr-1 h-3 w-3" /> Published
                        </span>
                      ) : (
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                          <EyeOff className="mr-1 h-3 w-3" /> Draft
                        </span>
                      )}
                    </TableCell>
                    <TableCell>{new Date(page.updatedAt).toLocaleDateString()}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleViewRevisions(page)}
                          title="View Revision History"
                        >
                          <Undo className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleEditPage(page)}
                          title="Edit Page"
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDeletePage(page)}
                          title="Delete Page"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-8">
                    <div className="flex flex-col items-center justify-center gap-2">
                      <p className="text-muted-foreground">No pages found</p>
                      <Button onClick={handleCreateNew}>Create Your First Page</Button>
                    </div>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      )}
      
      {/* Page Form */}
      {(isEditing || isCreating) && (
        <form onSubmit={handleSubmit} className="space-y-6 bg-card p-6 rounded-lg border shadow-sm">
          <h2 className="text-2xl font-bold">
            {isCreating ? "Create New Page" : "Edit Page"}
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  name="title"
                  value={formData.title}
                  onChange={handleTitleChange}
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="slug">Slug</Label>
                <Input
                  id="slug"
                  name="slug"
                  value={formData.slug}
                  onChange={handleInputChange}
                  required
                />
                <p className="text-xs text-muted-foreground">
                  URL-friendly version of the title (e.g., "about-us")
                </p>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="metaDescription">Meta Description</Label>
                <Input
                  id="metaDescription"
                  name="metaDescription"
                  value={formData.metaDescription}
                  onChange={handleInputChange}
                />
                <p className="text-xs text-muted-foreground">
                  Brief description for search engines (optional)
                </p>
              </div>
              
              <div className="flex items-center space-x-2">
                <Switch
                  id="isPublished"
                  checked={formData.isPublished}
                  onCheckedChange={handleSwitchChange}
                />
                <Label htmlFor="isPublished">Publish page</Label>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="content">Content</Label>
              <Textarea
                id="content"
                name="content"
                value={formData.content}
                onChange={handleInputChange}
                className="min-h-[300px]"
                required
              />
            </div>
          </div>
          
          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={handleCancel}>
              Cancel
            </Button>
            <Button type="submit" disabled={createPageMutation.isPending || updatePageMutation.isPending}>
              {createPageMutation.isPending || updatePageMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  Save Page
                </>
              )}
            </Button>
          </div>
        </form>
      )}
      
      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeletingPage} onOpenChange={setIsDeletingPage}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the page{" "}
              <span className="font-bold">{selectedPage?.title}</span> from the website.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDeletePage} className="bg-destructive text-destructive-foreground">
              {deletePageMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Deleting...
                </>
              ) : (
                "Delete Page"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      {/* Revisions Dialog */}
      <Dialog open={isRevisionsOpen} onOpenChange={setIsRevisionsOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Revision History</DialogTitle>
            <DialogDescription>
              View and restore previous versions of "{selectedPage?.title}"
            </DialogDescription>
          </DialogHeader>
          
          <div className="max-h-[400px] overflow-y-auto">
            {selectedPage?.revisions && selectedPage.revisions.length > 0 ? (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="revisionSelect">Select a revision to restore</Label>
                  <Select
                    value={selectedRevisionIndex !== null ? selectedRevisionIndex.toString() : ""}
                    onValueChange={(value) => setSelectedRevisionIndex(parseInt(value))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select a revision" />
                    </SelectTrigger>
                    <SelectContent>
                      {selectedPage.revisions.map((revision, index) => (
                        <SelectItem key={index} value={index.toString()}>
                          {new Date(revision.timestamp).toLocaleString()} - {revision.title}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                {selectedRevisionIndex !== null && (
                  <div className="space-y-2 p-4 border rounded-md bg-muted/50">
                    <div>
                      <h3 className="font-semibold">Title:</h3>
                      <p>{selectedPage.revisions[selectedRevisionIndex].title}</p>
                    </div>
                    <div>
                      <h3 className="font-semibold">Content:</h3>
                      <div className="max-h-[200px] overflow-y-auto p-2 border rounded-md bg-background">
                        <p className="whitespace-pre-wrap">
                          {selectedPage.revisions[selectedRevisionIndex].content}
                        </p>
                      </div>
                    </div>
                    <div>
                      <h3 className="font-semibold">Last Modified:</h3>
                      <p>{new Date(selectedPage.revisions[selectedRevisionIndex].timestamp).toLocaleString()}</p>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="py-8 text-center">
                <p className="text-muted-foreground">No revision history available</p>
              </div>
            )}
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setIsRevisionsOpen(false)}
            >
              Cancel
            </Button>
            <Button
              onClick={handleRestoreRevision}
              disabled={selectedRevisionIndex === null || restoreRevisionMutation.isPending}
            >
              {restoreRevisionMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Restoring...
                </>
              ) : (
                <>
                  <Undo className="mr-2 h-4 w-4" />
                  Restore Revision
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}