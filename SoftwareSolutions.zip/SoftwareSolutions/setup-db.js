import { spawn } from 'child_process';
import fs from 'fs';

// Helper to create a settings table SQL
const createSettingsTableSQL = `
CREATE TABLE IF NOT EXISTS "settings" (
  "key" TEXT PRIMARY KEY NOT NULL,
  "value" JSONB,
  "createdAt" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
`;

// Function to execute SQL queries
async function executeSQL(sql) {
  return new Promise((resolve, reject) => {
    const connectionString = process.env.DATABASE_URL;
    if (!connectionString) {
      return reject(new Error("DATABASE_URL environment variable is not set"));
    }

    const psql = spawn('psql', [connectionString, '-c', sql]);
    
    let stdout = '';
    let stderr = '';
    
    psql.stdout.on('data', (data) => {
      stdout += data.toString();
    });
    
    psql.stderr.on('data', (data) => {
      stderr += data.toString();
    });
    
    psql.on('close', (code) => {
      if (code !== 0) {
        console.error(`psql exited with code ${code}`);
        console.error(stderr);
        return reject(new Error(`psql error: ${stderr}`));
      }
      resolve(stdout);
    });
  });
}

async function main() {
  try {
    console.log('Creating settings table...');
    await executeSQL(createSettingsTableSQL);
    console.log('Settings table created or already exists.');
    
    console.log('Database setup completed successfully!');
  } catch (error) {
    console.error('Error during database setup:', error);
    process.exit(1);
  }
}

main();