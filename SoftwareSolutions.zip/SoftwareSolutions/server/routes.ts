import express, { type Express, type Request, type Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { contactFormSchema, paymentSchema, newsletterSchema } from "./schema";
import { insertProductSchema, insertPageSchema } from "@shared/schema";
import Stripe from "stripe";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import multer from "multer";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import { setupAuth, isAdmin } from "./auth";

// Get the directory name in ESM
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Configure multer for file uploads
const uploadDir = path.join(__dirname, "../uploads");

// Create uploads directory if it doesn't exist
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const storage2 = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, uploadDir);
  },
  filename: (_req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: storage2,
  limits: {
    fileSize: 5 * 1024 * 1024 // 5MB limit
  },
  fileFilter: (_req, file, cb) => {
    // Accept only images
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  }
});

if (!process.env.STRIPE_SECRET_KEY) {
  console.warn('Missing STRIPE_SECRET_KEY. Stripe functionality will not work properly.');
}

const stripe = process.env.STRIPE_SECRET_KEY 
  ? new Stripe(process.env.STRIPE_SECRET_KEY)
  : null;

export async function registerRoutes(app: Express): Promise<Server> {
  // Health check endpoint - helps keep the server running 100% of the time
  app.get('/healthz', (_req, res) => {
    res.status(200).send('OK');
  });
  
  // Set up authentication
  setupAuth(app);

  // API Routes
  app.get("/api/products", async (_req, res) => {
    try {
      const products = await storage.getProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });

  app.get("/api/products/:id", async (req, res) => {
    try {
      const product = await storage.getProduct(req.params.id);
      
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      res.json(product);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch product" });
    }
  });

  // Contact form submission
  app.post("/api/contact", async (req, res) => {
    try {
      const validatedData = contactFormSchema.parse(req.body);
      const timestamp = new Date().toISOString();
      
      // Add to contacts with timestamp
      await storage.createContact({
        ...validatedData,
        createdAt: timestamp
      });
      
      res.json({ success: true, message: "Message sent successfully" });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        res.status(400).json({ message: validationError.message });
      } else {
        res.status(500).json({ message: "Failed to send message" });
      }
    }
  });

  // Newsletter subscription
  app.post("/api/newsletter", async (req, res) => {
    try {
      const { email } = newsletterSchema.parse(req.body);
      
      // In a real app, you would store this email or send it to a mailing service
      // For now, we'll just return success
      
      res.json({ success: true, message: "Successfully subscribed to newsletter" });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        res.status(400).json({ message: validationError.message });
      } else {
        res.status(500).json({ message: "Failed to subscribe to newsletter" });
      }
    }
  });

  // Stripe payment route for one-time payments
  app.post("/api/create-payment-intent", async (req, res) => {
    if (!stripe) {
      return res.status(500).json({ message: "Stripe is not configured" });
    }
    
    try {
      const { productId, amount } = paymentSchema.parse(req.body);
      
      // Get the product to verify the amount
      const product = await storage.getProduct(productId);
      
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      // Use product price from database instead of client-provided amount for security
      const actualAmount = product.price;
      
      const paymentIntent = await stripe.paymentIntents.create({
        amount: actualAmount, // Already in cents in our database
        currency: "usd",
        metadata: { productId }
      });
      
      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        res.status(400).json({ message: validationError.message });
      } else {
        res.status(500).json({ 
          message: "Error creating payment intent",
          error: error instanceof Error ? error.message : String(error)
        });
      }
    }
  });
  
  // Stripe checkout session for direct checkout from featured products
  app.post("/api/create-checkout-session", async (req, res) => {
    if (!stripe) {
      return res.status(500).json({ message: "Stripe is not configured" });
    }
    
    try {
      const { priceId, productName, successUrl, cancelUrl } = req.body;
      
      if (!priceId || !successUrl || !cancelUrl) {
        return res.status(400).json({ message: "Missing required parameters" });
      }
      
      // Create checkout session
      const session = await stripe.checkout.sessions.create({
        payment_method_types: ["card"],
        line_items: [
          {
            price: priceId,
            quantity: 1,
          },
        ],
        mode: "payment",
        success_url: successUrl,
        cancel_url: cancelUrl,
        metadata: {
          productName
        },
      });
      
      res.json({ id: session.id });
    } catch (error) {
      console.error("Stripe checkout session error:", error);
      res.status(500).json({ 
        message: "Error creating checkout session",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // Donation endpoint
  app.post("/api/create-donation", async (req, res) => {
    if (!stripe) {
      return res.status(500).json({ message: "Stripe is not configured" });
    }
    
    try {
      const { amount, isRecurring, metadata } = req.body;
      
      if (!amount || amount < 1) {
        return res.status(400).json({ message: "Invalid donation amount" });
      }
      
      const formattedAmount = Math.round(amount * 100); // Convert to cents for Stripe
      
      // Get website settings for customizing donation experience
      const settings = await storage.getAllSettings();
      const businessName = settings.siteName || 'GrantedByFluffy';
      
      if (isRecurring) {
        // For recurring donations, create a subscription
        // First, we need to create a product and price
        const product = await stripe.products.create({
          name: `Monthly donation to ${businessName}`,
          description: 'Monthly supporter donation',
        });
        
        const price = await stripe.prices.create({
          product: product.id,
          unit_amount: formattedAmount,
          currency: 'usd',
          recurring: {
            interval: 'month',
          },
        });
        
        // Create a subscription checkout session
        const session = await stripe.checkout.sessions.create({
          payment_method_types: ['card'],
          line_items: [
            {
              price: price.id,
              quantity: 1,
            },
          ],
          mode: 'subscription',
          success_url: `${req.protocol}://${req.get('host')}/donate?success=true&type=recurring`,
          cancel_url: `${req.protocol}://${req.get('host')}/donate?canceled=true`,
          metadata: {
            donationType: 'recurring',
            donorName: metadata.name || 'Anonymous',
            donorEmail: metadata.email || '',
            donorMessage: metadata.message || '',
          },
        });
        
        res.json({ id: session.id, url: session.url });
        
      } else {
        // For one-time donations
        const session = await stripe.checkout.sessions.create({
          payment_method_types: ['card'],
          line_items: [
            {
              price_data: {
                currency: 'usd',
                product_data: {
                  name: `Donation to ${businessName}`,
                  description: 'One-time supporter donation',
                },
                unit_amount: formattedAmount,
              },
              quantity: 1,
            },
          ],
          mode: 'payment',
          success_url: `${req.protocol}://${req.get('host')}/donate?success=true&type=onetime`,
          cancel_url: `${req.protocol}://${req.get('host')}/donate?canceled=true`,
          metadata: {
            donationType: 'one-time',
            donorName: metadata.name || 'Anonymous',
            donorEmail: metadata.email || '',
            donorMessage: metadata.message || '',
          },
        });
        
        res.json({ id: session.id, url: session.url });
      }
    } catch (error) {
      console.error('Error creating donation:', error);
      res.status(500).json({ 
        message: 'Failed to process donation', 
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  // ==== ADMIN ROUTES ====
  
  // Get all products (admin view)
  app.get("/api/admin/products", isAdmin, async (_req, res) => {
    try {
      const products = await storage.getProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });
  
  // Create new product
  app.post("/api/admin/products", isAdmin, upload.single('image'), async (req: Request, res: Response) => {
    try {
      // Get form data
      const productData = JSON.parse(req.body.productData);
      
      // Validate product data
      const validatedData = insertProductSchema.parse({
        ...productData,
        // Convert price from dollars to cents
        price: productData.price ? Math.round(parseFloat(productData.price) * 100) : 0,
        discountPrice: productData.discountPrice ? Math.round(parseFloat(productData.discountPrice) * 100) : null,
        // Convert tags string to array
        tags: productData.tags ? productData.tags.split(',').map((tag: string) => tag.trim()) : []
      });
      
      // Set image URL if file was uploaded
      let imageUrl = validatedData.imageUrl;
      if (req.file) {
        // Use relative path to file from public directory
        imageUrl = `/uploads/${req.file.filename}`;
      }
      
      // Create product
      const newProduct = await storage.createProduct({
        ...validatedData,
        imageUrl
      });
      
      res.status(201).json(newProduct);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        res.status(400).json({ message: validationError.message });
      } else {
        console.error('Error creating product:', error);
        res.status(500).json({ 
          message: "Failed to create product",
          error: error instanceof Error ? error.message : String(error)
        });
      }
    }
  });
  
  // Update product
  app.put("/api/admin/products/:id", isAdmin, upload.single('image'), async (req, res) => {
    try {
      const productId = req.params.id;
      
      // Verify product exists
      const existingProduct = await storage.getProduct(productId);
      if (!existingProduct) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      // Get form data
      const productData = JSON.parse(req.body.productData);
      
      // Prepare update data
      const updateData: any = {
        ...productData,
        // Convert price from dollars to cents if provided
        price: productData.price ? Math.round(parseFloat(productData.price) * 100) : undefined,
        discountPrice: productData.discountPrice ? Math.round(parseFloat(productData.discountPrice) * 100) : null,
        // Convert tags string to array if provided
        tags: productData.tags ? productData.tags.split(',').map((tag: string) => tag.trim()) : undefined
      };
      
      // Set image URL if file was uploaded
      if (req.file) {
        // Use relative path to file from public directory
        updateData.imageUrl = `/uploads/${req.file.filename}`;
        
        // Delete old image if it exists and is in our uploads directory
        if (existingProduct.imageUrl && existingProduct.imageUrl.startsWith('/uploads/')) {
          const oldImagePath = path.join(__dirname, '../public', existingProduct.imageUrl);
          if (fs.existsSync(oldImagePath)) {
            fs.unlinkSync(oldImagePath);
          }
        }
      }
      
      // Update product
      const updatedProduct = await storage.updateProduct(productId, updateData);
      
      res.json(updatedProduct);
    } catch (error) {
      console.error('Error updating product:', error);
      res.status(500).json({ 
        message: "Failed to update product",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // Delete product
  app.delete("/api/admin/products/:id", isAdmin, async (req, res) => {
    try {
      const productId = req.params.id;
      
      // Verify product exists
      const existingProduct = await storage.getProduct(productId);
      if (!existingProduct) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      // Delete product image if it exists and is in our uploads directory
      if (existingProduct.imageUrl && existingProduct.imageUrl.startsWith('/uploads/')) {
        const imagePath = path.join(__dirname, '../public', existingProduct.imageUrl);
        if (fs.existsSync(imagePath)) {
          fs.unlinkSync(imagePath);
        }
      }
      
      // Delete product
      await storage.deleteProduct(productId);
      
      res.json({ success: true, message: "Product deleted successfully" });
    } catch (error) {
      console.error('Error deleting product:', error);
      res.status(500).json({ 
        message: "Failed to delete product",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  // ==== PAGE MANAGEMENT ROUTES ====
  
  // Get all pages (public)
  app.get("/api/pages", async (_req, res) => {
    try {
      // Only return published pages for public view
      const allPages = await storage.getPages();
      const publishedPages = allPages.filter(page => page.isPublished);
      res.json(publishedPages);
    } catch (error) {
      console.error('Error fetching pages:', error);
      res.status(500).json({ message: "Failed to fetch pages" });
    }
  });
  
  // Get single page by slug (public)
  app.get("/api/pages/by-slug/:slug", async (req, res) => {
    try {
      const page = await storage.getPageBySlug(req.params.slug);
      
      if (!page || !page.isPublished) {
        return res.status(404).json({ message: "Page not found" });
      }
      
      res.json(page);
    } catch (error) {
      console.error('Error fetching page:', error);
      res.status(500).json({ message: "Failed to fetch page" });
    }
  });
  
  // ==== ADMIN PAGE MANAGEMENT ROUTES ====
  
  // Get all pages (admin view - includes unpublished)
  app.get("/api/admin/pages", isAdmin, async (_req, res) => {
    try {
      const pages = await storage.getPages();
      res.json(pages);
    } catch (error) {
      console.error('Error fetching pages:', error);
      res.status(500).json({ message: "Failed to fetch pages" });
    }
  });
  
  // Get single page by ID (admin)
  app.get("/api/admin/pages/:id", isAdmin, async (req, res) => {
    try {
      const pageId = parseInt(req.params.id);
      if (isNaN(pageId)) {
        return res.status(400).json({ message: "Invalid page ID" });
      }
      
      const page = await storage.getPage(pageId);
      
      if (!page) {
        return res.status(404).json({ message: "Page not found" });
      }
      
      res.json(page);
    } catch (error) {
      console.error('Error fetching page:', error);
      res.status(500).json({ message: "Failed to fetch page" });
    }
  });
  
  // Create new page (admin)
  app.post("/api/admin/pages", isAdmin, async (req, res) => {
    try {
      // Validate page data
      const validatedData = insertPageSchema.parse(req.body);
      
      // Check if slug is already used
      const existingPage = await storage.getPageBySlug(validatedData.slug);
      if (existingPage) {
        return res.status(400).json({ message: "Slug is already in use" });
      }
      
      // Create page
      const newPage = await storage.createPage(validatedData);
      
      res.status(201).json(newPage);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        res.status(400).json({ message: validationError.message });
      } else {
        console.error('Error creating page:', error);
        res.status(500).json({ 
          message: "Failed to create page",
          error: error instanceof Error ? error.message : String(error)
        });
      }
    }
  });
  
  // Update page (admin)
  app.put("/api/admin/pages/:id", isAdmin, async (req, res) => {
    try {
      const pageId = parseInt(req.params.id);
      if (isNaN(pageId)) {
        return res.status(400).json({ message: "Invalid page ID" });
      }
      
      // Verify page exists
      const existingPage = await storage.getPage(pageId);
      if (!existingPage) {
        return res.status(404).json({ message: "Page not found" });
      }
      
      // Check if updated slug is already used by another page
      if (req.body.slug && req.body.slug !== existingPage.slug) {
        const pageWithSlug = await storage.getPageBySlug(req.body.slug);
        if (pageWithSlug && pageWithSlug.id !== pageId) {
          return res.status(400).json({ message: "Slug is already in use" });
        }
      }
      
      // Handle revisions
      const saveRevision = req.body.saveRevision !== false;
      delete req.body.saveRevision; // Remove from data to be saved
      
      // Update page
      const updatedPage = await storage.updatePage(pageId, req.body, saveRevision);
      
      res.json(updatedPage);
    } catch (error) {
      console.error('Error updating page:', error);
      res.status(500).json({ 
        message: "Failed to update page",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // Delete page (admin)
  app.delete("/api/admin/pages/:id", isAdmin, async (req, res) => {
    try {
      const pageId = parseInt(req.params.id);
      if (isNaN(pageId)) {
        return res.status(400).json({ message: "Invalid page ID" });
      }
      
      // Verify page exists
      const existingPage = await storage.getPage(pageId);
      if (!existingPage) {
        return res.status(404).json({ message: "Page not found" });
      }
      
      // Delete page
      await storage.deletePage(pageId);
      
      res.json({ success: true, message: "Page deleted successfully" });
    } catch (error) {
      console.error('Error deleting page:', error);
      res.status(500).json({ 
        message: "Failed to delete page",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // Get page revisions (admin)
  app.get("/api/admin/pages/:id/revisions", isAdmin, async (req, res) => {
    try {
      const pageId = parseInt(req.params.id);
      if (isNaN(pageId)) {
        return res.status(400).json({ message: "Invalid page ID" });
      }
      
      // Verify page exists
      const existingPage = await storage.getPage(pageId);
      if (!existingPage) {
        return res.status(404).json({ message: "Page not found" });
      }
      
      // Get revisions
      const revisions = await storage.getPageRevisions(pageId);
      
      res.json(revisions);
    } catch (error) {
      console.error('Error fetching page revisions:', error);
      res.status(500).json({ 
        message: "Failed to fetch page revisions",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // Restore page revision (admin)
  app.post("/api/admin/pages/:id/restore/:revisionIndex", isAdmin, async (req, res) => {
    try {
      const pageId = parseInt(req.params.id);
      const revisionIndex = parseInt(req.params.revisionIndex);
      
      if (isNaN(pageId) || isNaN(revisionIndex)) {
        return res.status(400).json({ message: "Invalid page ID or revision index" });
      }
      
      // Verify page exists
      const existingPage = await storage.getPage(pageId);
      if (!existingPage) {
        return res.status(404).json({ message: "Page not found" });
      }
      
      // Restore revision
      const restoredPage = await storage.restorePageRevision(pageId, revisionIndex);
      
      if (!restoredPage) {
        return res.status(404).json({ message: "Revision not found" });
      }
      
      res.json(restoredPage);
    } catch (error) {
      console.error('Error restoring page revision:', error);
      res.status(500).json({ 
        message: "Failed to restore page revision",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  // Website Settings API Routes
  
  // Get all settings
  app.get("/api/settings", async (req, res) => {
    try {
      // Disable caching for settings
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');
      
      const settings = await storage.getAllSettings();
      res.json(settings);
    } catch (error) {
      console.error('Error fetching settings:', error);
      res.status(500).json({ message: "Failed to fetch settings" });
    }
  });

  // Get setting by key
  app.get("/api/settings/:key", async (req, res) => {
    try {
      // Disable caching for settings
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');
      
      const { key } = req.params;
      const value = await storage.getSetting(key);
      
      if (value === null) {
        return res.status(404).json({ message: "Setting not found" });
      }
      
      res.json({ key, value });
    } catch (error) {
      console.error('Error fetching setting:', error);
      res.status(500).json({ message: "Failed to fetch setting" });
    }
  });

  // Update setting (admin only)
  app.put("/api/admin/settings/:key", isAdmin, async (req, res) => {
    try {
      const { key } = req.params;
      const { value } = req.body;
      
      if (value === undefined) {
        return res.status(400).json({ message: "Value is required" });
      }
      
      await storage.updateSetting(key, value);
      res.json({ key, value });
    } catch (error) {
      console.error('Error updating setting:', error);
      res.status(500).json({ message: "Failed to update setting" });
    }
  });

  // Batch update settings (admin only)
  app.post("/api/admin/settings", isAdmin, async (req, res) => {
    try {
      const settings = req.body;
      
      if (!settings || typeof settings !== 'object') {
        return res.status(400).json({ message: "Invalid settings object" });
      }
      
      const updatedSettings: Record<string, any> = {};
      
      // Update each setting
      for (const [key, value] of Object.entries(settings)) {
        await storage.updateSetting(key, value);
        updatedSettings[key] = value;
      }
      
      res.json(updatedSettings);
    } catch (error) {
      console.error('Error updating settings:', error);
      res.status(500).json({ message: "Failed to update settings" });
    }
  });

  // Serve uploaded files
  app.use('/uploads', express.static(uploadDir));

  const httpServer = createServer(app);
  return httpServer;
}
