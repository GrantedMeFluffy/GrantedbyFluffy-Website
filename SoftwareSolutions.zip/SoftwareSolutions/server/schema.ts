import { z } from "zod";

// Contact form schema for validation
export const contactFormSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Please enter a valid email address"),
  subject: z.string().min(2, "Subject must be at least 2 characters"),
  message: z.string().min(10, "Message must be at least 10 characters"),
});

// Payment schema for Stripe
export const paymentSchema = z.object({
  productId: z.string(),
  amount: z.number().positive("Amount must be positive"),
});

// Newsletter subscription schema
export const newsletterSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
});

// Product type for the shop
export type Product = {
  id: string;
  name: string;
  description: string;
  price: number;
  discountPrice?: number;
  imageUrl: string;
  tags: string[];
  featured?: boolean;
  new?: boolean;
};

// Service type for the service section
export type Service = {
  id: string;
  title: string;
  description: string;
  icon: string;
  features: string[];
};

// Portfolio project type
export type Project = {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  technologies: string[];
  highlights: string[];
};

// Sample products data
export const products: Product[] = [
  {
    id: "dev-tracker-pro",
    name: "DevTracker Pro",
    description: "All-in-one project management tool designed specifically for software developers and teams.",
    price: 4900,
    discountPrice: 7900,
    imageUrl: "https://images.unsplash.com/photo-1484417894907-623942c8ee29",
    tags: ["Project Management", "Time Tracking", "Git Integration"],
    featured: true
  },
  {
    id: "code-analyzer",
    name: "CodeAnalyzer",
    description: "Advanced code quality analysis tool with automated refactoring suggestions and optimization tips.",
    price: 3900,
    discountPrice: 5900,
    imageUrl: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97",
    tags: ["Code Quality", "Refactoring", "Performance"]
  },
  {
    id: "ux-prototyper",
    name: "UXPrototyper",
    description: "Rapid prototyping tool for creating interactive UI mockups with real-time collaboration features.",
    price: 5900,
    discountPrice: 8900,
    imageUrl: "https://images.unsplash.com/photo-1551033406-611cf9a28f67",
    tags: ["UI Design", "Prototyping", "Collaboration"],
    new: true
  }
];

// Sample services data
export const services: Service[] = [
  {
    id: "custom-software",
    title: "Custom Software Development",
    description: "End-to-end development of bespoke software solutions that address your specific business challenges.",
    icon: "laptop-code",
    features: ["Web Applications", "Mobile Solutions", "Desktop Software"]
  },
  {
    id: "api-development",
    title: "API Development & Integration",
    description: "Create robust APIs and integrate third-party services to extend your software capabilities.",
    icon: "code",
    features: ["RESTful APIs", "Payment Gateways", "Third-party Services"]
  },
  {
    id: "ui-ux-design",
    title: "UI/UX Design",
    description: "Create intuitive, engaging user experiences that delight your customers and drive engagement.",
    icon: "mobile-alt",
    features: ["User Research", "Interface Design", "Usability Testing"]
  }
];

// Sample projects data
export const projects: Project[] = [
  {
    id: "ecommerce-platform",
    title: "E-commerce Platform",
    description: "Custom e-commerce platform with advanced product filtering, real-time inventory, and integrated payment gateways.",
    imageUrl: "https://images.unsplash.com/photo-1551434678-e076c223a692",
    technologies: ["React", "Node.js", "MongoDB"],
    highlights: [
      "Increased conversion rates by 35% through optimized UX",
      "Reduced page load time by 60% with code optimization",
      "Seamless integration with multiple payment gateways"
    ]
  },
  {
    id: "analytics-dashboard",
    title: "Analytics Dashboard",
    description: "Real-time analytics dashboard with customizable metrics, interactive visualizations, and automated reporting.",
    imageUrl: "https://images.unsplash.com/photo-1534972195531-d756b9bfa9f2",
    technologies: ["Vue.js", "Python", "PostgreSQL"],
    highlights: [
      "Reduced decision-making time by 40% with real-time insights",
      "Customizable dashboard with drag-and-drop interface",
      "Automated reporting system saving 15 hours per week"
    ]
  },
  {
    id: "health-fitness-app",
    title: "Health & Fitness App",
    description: "Comprehensive health tracking app with personalized workout plans, nutrition guidance, and progress analytics.",
    imageUrl: "https://images.unsplash.com/photo-1616469829581-73993eb86b02",
    technologies: ["React Native", "Firebase", "GraphQL"],
    highlights: [
      "50,000+ downloads in first month after launch",
      "AI-powered workout recommendations",
      "Wearable device integration with real-time sync"
    ]
  }
];
