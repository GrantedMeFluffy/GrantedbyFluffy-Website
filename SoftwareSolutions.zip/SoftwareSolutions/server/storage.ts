import { 
  users, products, contacts, pages, settings,
  type User, type InsertUser, 
  type InsertContact, type InsertProduct,
  type Page, type InsertPage,
  type Settings, type InsertSettings
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";
import { v4 as uuidv4 } from "uuid";
import { products as initialProducts } from "./schema";

// Contact form submission type
export type ContactSubmission = {
  name: string;
  email: string;
  subject: string;
  message: string;
  createdAt: string;
}

// We need to adapt the sample products to match our schema
export interface SampleProduct {
  id: string;
  name: string;
  description: string;
  price: number;
  discountPrice?: number;
  imageUrl: string;
  tags: string[];
  featured?: boolean;
  new?: boolean;
}

// Type for our product storage format
export interface StoredProduct {
  id: string;
  name: string;
  description: string;
  price: number;
  imageUrl: string | null;
  tags: string[] | null;
  stripePriceId: string | null;
  featured: boolean | null;
  discountPrice: number | null;
}

// modify the interface with any CRUD methods
// you might need
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Contact methods
  createContact(contact: ContactSubmission): Promise<void>;
  
  // Product methods
  getProducts(): Promise<StoredProduct[]>;
  getProduct(id: string): Promise<StoredProduct | undefined>;
  createProduct(product: InsertProduct): Promise<StoredProduct>;
  updateProduct(id: string, product: Partial<InsertProduct>): Promise<StoredProduct | undefined>;
  deleteProduct(id: string): Promise<boolean>;
  
  // Page methods
  getPages(): Promise<Page[]>;
  getPage(id: number): Promise<Page | undefined>;
  getPageBySlug(slug: string): Promise<Page | undefined>;
  createPage(page: InsertPage): Promise<Page>;
  updatePage(id: number, page: Partial<InsertPage>, saveRevision?: boolean): Promise<Page | undefined>;
  deletePage(id: number): Promise<boolean>;
  getPageRevisions(id: number): Promise<any[]>;
  restorePageRevision(id: number, revisionIndex: number): Promise<Page | undefined>;
  
  // Website settings methods
  getSetting(key: string): Promise<any>;
  getAllSettings(): Promise<Record<string, any>>;
  updateSetting(key: string, value: any): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private contacts: ContactSubmission[];
  private products: Map<string, StoredProduct>;
  private pages: Map<number, Page>;
  private settingsMap: Map<string, any>;
  currentUserId: number;
  currentProductId: number;
  currentPageId: number;

  constructor() {
    this.users = new Map();
    this.contacts = [];
    this.products = new Map();
    this.pages = new Map();
    this.settingsMap = new Map();
    this.currentUserId = 1;
    this.currentProductId = 1;
    this.currentPageId = 1;
    
    // Initialize with sample products
    (initialProducts as SampleProduct[]).forEach(product => {
      this.products.set(product.id, {
        id: product.id,
        name: product.name,
        description: product.description,
        price: product.price,
        imageUrl: product.imageUrl || null,
        tags: product.tags || null,
        stripePriceId: null,
        featured: product.featured || null,
        discountPrice: product.discountPrice || null
      });
    });
    
    // Create default admin user
    this.createUser({
      username: "admin",
      password: "$2b$10$8Ux9iCTgxnQsnSKD3A8EjeZlJr0A2GQPEULLHakyBf2jGwzlcJV.a", // "password" - this would be properly hashed in production
      isAdmin: true as boolean
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id,
      isAdmin: insertUser.isAdmin === undefined ? false : insertUser.isAdmin
    };
    this.users.set(id, user);
    return user;
  }
  
  async createContact(contact: ContactSubmission): Promise<void> {
    this.contacts.push(contact);
  }
  
  // Product methods
  async getProducts(): Promise<StoredProduct[]> {
    return Array.from(this.products.values());
  }
  
  async getProduct(id: string): Promise<StoredProduct | undefined> {
    return this.products.get(id);
  }
  
  async createProduct(product: InsertProduct): Promise<StoredProduct> {
    const id = `product-${this.currentProductId++}`;
    const newProduct: StoredProduct = { 
      id,
      name: product.name,
      description: product.description,
      price: product.price,
      imageUrl: product.imageUrl || null,
      tags: product.tags || null,
      stripePriceId: product.stripePriceId || null,
      featured: product.featured || null,
      discountPrice: product.discountPrice || null
    };
    this.products.set(id, newProduct);
    return newProduct;
  }
  
  async updateProduct(id: string, productUpdate: Partial<InsertProduct>): Promise<StoredProduct | undefined> {
    const existingProduct = this.products.get(id);
    
    if (!existingProduct) {
      return undefined;
    }
    
    const updatedProduct: StoredProduct = {
      ...existingProduct,
      name: productUpdate.name !== undefined ? productUpdate.name : existingProduct.name,
      description: productUpdate.description !== undefined ? productUpdate.description : existingProduct.description,
      price: productUpdate.price !== undefined ? productUpdate.price : existingProduct.price,
      imageUrl: productUpdate.imageUrl !== undefined ? productUpdate.imageUrl : existingProduct.imageUrl,
      tags: productUpdate.tags !== undefined ? productUpdate.tags : existingProduct.tags,
      stripePriceId: productUpdate.stripePriceId !== undefined ? productUpdate.stripePriceId : existingProduct.stripePriceId,
      featured: productUpdate.featured !== undefined ? productUpdate.featured : existingProduct.featured,
      discountPrice: productUpdate.discountPrice !== undefined ? productUpdate.discountPrice : existingProduct.discountPrice
    };
    
    this.products.set(id, updatedProduct);
    return updatedProduct;
  }
  
  async deleteProduct(id: string): Promise<boolean> {
    return this.products.delete(id);
  }
  
  // Page methods
  async getPages(): Promise<Page[]> {
    return Array.from(this.pages.values());
  }

  async getPage(id: number): Promise<Page | undefined> {
    return this.pages.get(id);
  }

  async getPageBySlug(slug: string): Promise<Page | undefined> {
    return Array.from(this.pages.values()).find(page => page.slug === slug);
  }

  async createPage(page: InsertPage): Promise<Page> {
    const id = this.currentPageId++;
    const now = new Date();
    const newPage: Page = {
      id,
      title: page.title,
      slug: page.slug,
      content: page.content,
      isPublished: page.isPublished ?? true,
      metaDescription: page.metaDescription || null,
      createdAt: now,
      updatedAt: now,
      revisions: [] as any[] // Initialize empty revisions array
    };
    
    this.pages.set(id, newPage);
    return newPage;
  }

  async updatePage(id: number, pageUpdate: Partial<InsertPage>, saveRevision: boolean = true): Promise<Page | undefined> {
    const existingPage = this.pages.get(id);
    
    if (!existingPage) {
      return undefined;
    }
    
    // Get current revisions safely
    let currentRevisions: any[] = [];
    if (existingPage.revisions) {
      currentRevisions = Array.isArray(existingPage.revisions) ? existingPage.revisions : [];
    }
    
    // Save current version as revision if requested
    if (saveRevision) {
      const newRevision = {
        title: existingPage.title,
        content: existingPage.content,
        timestamp: new Date().toISOString(),
      };
      
      currentRevisions.push(newRevision);
    }
    
    // Update the page
    const updatedPage: Page = {
      ...existingPage,
      title: pageUpdate.title !== undefined ? pageUpdate.title : existingPage.title,
      slug: pageUpdate.slug !== undefined ? pageUpdate.slug : existingPage.slug,
      content: pageUpdate.content !== undefined ? pageUpdate.content : existingPage.content,
      isPublished: pageUpdate.isPublished !== undefined ? pageUpdate.isPublished : existingPage.isPublished,
      metaDescription: pageUpdate.metaDescription !== undefined ? pageUpdate.metaDescription : existingPage.metaDescription,
      updatedAt: new Date(),
      revisions: currentRevisions
    };
    
    this.pages.set(id, updatedPage);
    return updatedPage;
  }

  async deletePage(id: number): Promise<boolean> {
    return this.pages.delete(id);
  }

  async getPageRevisions(id: number): Promise<any[]> {
    const page = this.pages.get(id);
    if (!page || !page.revisions) return [];
    return Array.isArray(page.revisions) ? page.revisions : [];
  }

  async restorePageRevision(id: number, revisionIndex: number): Promise<Page | undefined> {
    const page = this.pages.get(id);
    const revisions = await this.getPageRevisions(id);
    
    if (!page || revisionIndex >= revisions.length) {
      return undefined;
    }
    
    const revision = revisions[revisionIndex];
    
    // Save current state as a revision before restoring
    await this.updatePage(id, {}, true);
    
    // Restore the selected revision
    return await this.updatePage(id, {
      title: revision.title,
      content: revision.content
    }, false);
  }
  
  // Website settings methods
  async getSetting(key: string): Promise<any> {
    return this.settingsMap.get(key) || null;
  }
  
  async getAllSettings(): Promise<Record<string, any>> {
    const result: Record<string, any> = {};
    // Convert Map to array of entries, then iterate
    Array.from(this.settingsMap.entries()).forEach(([key, value]) => {
      result[key] = value;
    });
    return result;
  }
  
  async updateSetting(key: string, value: any): Promise<void> {
    this.settingsMap.set(key, value);
  }
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }
  
  async createContact(contactData: ContactSubmission): Promise<void> {
    const insertContact: InsertContact = {
      name: contactData.name,
      email: contactData.email,
      subject: contactData.subject,
      message: contactData.message,
    };
    
    await db.insert(contacts).values({
      ...insertContact,
      createdAt: contactData.createdAt,
    });
  }
  
  async getProducts(): Promise<StoredProduct[]> {
    const productList = await db.select().from(products);
    return productList.map(product => ({
      id: product.id,
      name: product.name,
      description: product.description,
      price: product.price,
      imageUrl: product.imageUrl || null,
      tags: product.tags || null,
      stripePriceId: product.stripePriceId || null,
      featured: product.featured || null,
      discountPrice: product.discountPrice || null
    }));
  }
  
  async getProduct(id: string): Promise<StoredProduct | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    
    if (!product) {
      return undefined;
    }
    
    return {
      id: product.id,
      name: product.name,
      description: product.description,
      price: product.price,
      imageUrl: product.imageUrl || null,
      tags: product.tags || null,
      stripePriceId: product.stripePriceId || null,
      featured: product.featured || null,
      discountPrice: product.discountPrice || null
    };
  }
  
  async createProduct(product: InsertProduct): Promise<StoredProduct> {
    const id = `product-${uuidv4()}`;
    
    const [newProduct] = await db
      .insert(products)
      .values({
        id,
        name: product.name,
        description: product.description,
        price: product.price,
        imageUrl: product.imageUrl || null,
        tags: product.tags || null,
        stripePriceId: product.stripePriceId || null,
        featured: product.featured || null,
        discountPrice: product.discountPrice || null
      })
      .returning();
    
    return {
      id: newProduct.id,
      name: newProduct.name,
      description: newProduct.description,
      price: newProduct.price,
      imageUrl: newProduct.imageUrl || null,
      tags: newProduct.tags || null,
      stripePriceId: newProduct.stripePriceId || null,
      featured: newProduct.featured || null,
      discountPrice: newProduct.discountPrice || null
    };
  }
  
  async updateProduct(id: string, productUpdate: Partial<InsertProduct>): Promise<StoredProduct | undefined> {
    const existingProduct = await this.getProduct(id);
    
    if (!existingProduct) {
      return undefined;
    }
    
    const [updatedProduct] = await db
      .update(products)
      .set({
        name: productUpdate.name !== undefined ? productUpdate.name : existingProduct.name,
        description: productUpdate.description !== undefined ? productUpdate.description : existingProduct.description,
        price: productUpdate.price !== undefined ? productUpdate.price : existingProduct.price,
        imageUrl: productUpdate.imageUrl !== undefined ? productUpdate.imageUrl : existingProduct.imageUrl,
        tags: productUpdate.tags !== undefined ? productUpdate.tags : existingProduct.tags,
        stripePriceId: productUpdate.stripePriceId !== undefined ? productUpdate.stripePriceId : existingProduct.stripePriceId,
        featured: productUpdate.featured !== undefined ? productUpdate.featured : existingProduct.featured,
        discountPrice: productUpdate.discountPrice !== undefined ? productUpdate.discountPrice : existingProduct.discountPrice
      })
      .where(eq(products.id, id))
      .returning();
    
    return {
      id: updatedProduct.id,
      name: updatedProduct.name,
      description: updatedProduct.description,
      price: updatedProduct.price,
      imageUrl: updatedProduct.imageUrl || null,
      tags: updatedProduct.tags || null,
      stripePriceId: updatedProduct.stripePriceId || null,
      featured: updatedProduct.featured || null,
      discountPrice: updatedProduct.discountPrice || null
    };
  }
  
  async deleteProduct(id: string): Promise<boolean> {
    const result = await db
      .delete(products)
      .where(eq(products.id, id))
      .returning({ id: products.id });
    
    return result.length > 0;
  }

  // Page methods
  async getPages(): Promise<Page[]> {
    return await db.select().from(pages);
  }

  async getPage(id: number): Promise<Page | undefined> {
    const [page] = await db.select().from(pages).where(eq(pages.id, id));
    return page || undefined;
  }

  async getPageBySlug(slug: string): Promise<Page | undefined> {
    const [page] = await db.select().from(pages).where(eq(pages.slug, slug));
    return page || undefined;
  }

  async createPage(pageData: InsertPage): Promise<Page> {
    const [page] = await db
      .insert(pages)
      .values({
        ...pageData,
        revisions: [] as any[] // Initialize empty revisions array
      })
      .returning();
    return page;
  }

  async updatePage(id: number, pageUpdate: Partial<InsertPage>, saveRevision: boolean = true): Promise<Page | undefined> {
    const existingPage = await this.getPage(id);
    
    if (!existingPage) {
      return undefined;
    }
    
    // Get current revisions safely
    let currentRevisions: any[] = [];
    if (existingPage.revisions) {
      currentRevisions = Array.isArray(existingPage.revisions) ? existingPage.revisions : [];
    }
    
    // Save current version as revision if requested
    if (saveRevision) {
      const newRevision = {
        title: existingPage.title,
        content: existingPage.content,
        timestamp: new Date().toISOString(),
      };
      
      await db
        .update(pages)
        .set({ 
          revisions: [...currentRevisions, newRevision] as any[]
        })
        .where(eq(pages.id, id));
    }
    
    // Update the page
    const [updatedPage] = await db
      .update(pages)
      .set({
        title: pageUpdate.title !== undefined ? pageUpdate.title : existingPage.title,
        slug: pageUpdate.slug !== undefined ? pageUpdate.slug : existingPage.slug,
        content: pageUpdate.content !== undefined ? pageUpdate.content : existingPage.content,
        isPublished: pageUpdate.isPublished !== undefined ? pageUpdate.isPublished : existingPage.isPublished,
        metaDescription: pageUpdate.metaDescription !== undefined ? pageUpdate.metaDescription : existingPage.metaDescription,
        updatedAt: new Date()
      })
      .where(eq(pages.id, id))
      .returning();
    
    return updatedPage;
  }

  async deletePage(id: number): Promise<boolean> {
    const result = await db
      .delete(pages)
      .where(eq(pages.id, id))
      .returning({ id: pages.id });
    
    return result.length > 0;
  }

  async getPageRevisions(id: number): Promise<any[]> {
    const page = await this.getPage(id);
    if (!page || !page.revisions) return [];
    return Array.isArray(page.revisions) ? page.revisions : [];
  }

  async restorePageRevision(id: number, revisionIndex: number): Promise<Page | undefined> {
    const page = await this.getPage(id);
    const revisions = await this.getPageRevisions(id);
    
    if (!page || revisionIndex >= revisions.length) {
      return undefined;
    }
    
    const revision = revisions[revisionIndex];
    
    // Save current state as a revision before restoring
    await this.updatePage(id, {}, true);
    
    // Restore the selected revision
    return await this.updatePage(id, {
      title: revision.title,
      content: revision.content
    }, false);
  }

  // Website settings methods
  async getSetting(key: string): Promise<any> {
    try {
      const [setting] = await db.select({
        value: settings.value
      }).from(settings).where(eq(settings.key, key));
      return setting ? setting.value : null;
    } catch (error) {
      console.error('Error in getSetting:', error);
      return null;
    }
  }

  async getAllSettings(): Promise<Record<string, any>> {
    try {
      const allSettings = await db.select({
        key: settings.key,
        value: settings.value
      }).from(settings);
      
      return allSettings.reduce((acc, setting) => {
        acc[setting.key] = setting.value;
        return acc;
      }, {} as Record<string, any>);
    } catch (error) {
      console.error('Error in getAllSettings:', error);
      return {};
    }
  }

  async updateSetting(key: string, value: any): Promise<void> {
    try {
      const [existingSetting] = await db.select({
        key: settings.key
      }).from(settings).where(eq(settings.key, key));
      
      if (existingSetting) {
        await db
          .update(settings)
          .set({ 
            value: value as any,
            updatedAt: new Date()
          })
          .where(eq(settings.key, key));
      } else {
        await db
          .insert(settings)
          .values({
            key,
            value: value as any
          });
      }
    } catch (error) {
      console.error('Error in updateSetting:', error);
      throw error;
    }
  }
}

// Use the database storage implementation
export const storage = new DatabaseStorage();